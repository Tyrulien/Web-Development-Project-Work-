<?php

Class profileU {
  public $profileid;

  public $username;

  public $passwordU;

  public $phonenumber;

  public $dateofbirth;

  public $cardnumber;

  
  public function setprofileid($profileid) {
    $this->profileid = $profileid;
  }

  public function getprofileid() {
    return $this->profileid;
}
public function setusername($username) {
 $this->username = $username;
}
public function getusername() { 
    return $this->username;
}
public function setpasswordU($passwordU) {
    $this->passwordU = $passwordU;


}
public function getpasswordU() {
    return $this->passwordU;
}
public function setphonenumber($phonenumber) {
    $this->phonenumber = $phonenumber;
}
public function getphonenumber() {
    return $this->phonenumber;
}
public function setdateofbirth($dateofbirth) {
    $this->dateofbirth = $dateofbirth;
}
public function getdateofbirth() {
    return $this->dateofbirth;
}

public function setcardnumber($cardnumber) {
    $this->dateofbirth = $cardnumber;
}
public function getcardnumber() {
    return $this->cardnumber;
}

public function updateProfile(){
    echo "Make: " . $this->getusername() . "<br/>";
    echo "username: " . $this->getdateofbirth() . "<br/>";
    echo "Engine: ". $this->getphonenumber() . "<br/>";
    echo "Model: ". $this->getpasswordU() . "<br/>";


}
}

    $profileA = new profileU();
    $profileB = new profileU();

    // code for profile A
    $profileA->setprofileid('11111');
    $profileA->setusername('BMW');
    $profileA->setdateofbirth('45000');
    $profileA->setpasswordU('3 Series');
    $profileA->setphonenumber('2K40');

    // code for profile B
    $profileB->setprofileid('22222');
    $profileB->setusername('Mercedes-Benz');
    $profileB->setdateofbirth('60000');
    $profileB->setpasswordU('S Class');
    $profileB->setphonenumber('Turbin');


    $profileA->updateProfile();
    $profileB->updateProfile();
    ?>