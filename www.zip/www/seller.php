<?php

Class Seller {
  public $sellerNumber;

  public $sellerName;

  public $sellerBio;



  public function setsellerNumber($sellerNumber) {
    $this->sellerNumber = $sellerNumber;
  }

  public function getsellerNumber() {
    return $this->sellerNumber;
}
public function setsellerName($sellerName) {
 $this->sellerName = $sellerName;
}
public function getsellerName() { 
    return $this->sellerName;
}
public function setsellerBio($sellerBio) {
    $this->sellerBio = $sellerBio;


}
public function getsellerBio() {
    return $this->sellerBio;
}

public function displaySeller(){
    echo "Make: " . $this->getsellerName() . "<br/>";
    echo "Price: " . $this->getsellerNumber() . "<br/>";
    echo "Model: ". $this->getsellerBio() . "<br/>";

}
}

    $SellerA = new Seller();
    $SellerB = new Seller();

    // code for car A
    $SellerA->setsellerNumber('11111');
    $SellerA->setsellerName('BMW');
    $SellerA->setsellerBio('3 Series');

    // code for car B
    $SellerB->setsellerNumber('22222');
    $SellerB->setsellerName('Mercedes-Benz');
    $SellerB->setsellerBio('S Class');


    $SellerA->displaySeller();
    $SellerB->displaySeller();
    ?>