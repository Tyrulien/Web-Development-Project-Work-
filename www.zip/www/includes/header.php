<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Simple Shop</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/header.css">
    <link rel="stylesheet" href="/css/footer.css">
</head>
<body>
    <header style="display: flex; align-items: center; justify-content: space-between; background-color: #f4f4f4; padding: 10px 20px; border-bottom: 1px solid #ddd;">
        <div style="flex: 1; display: flex; align-items: center;">
            <a href="/" style="font-size: 1.5em; text-decoration: none; color: #333;">Shop Logo</a>
        </div>
        <nav style="flex: 2; display: flex; justify-content: center;">
            <ul style="list-style-type: none; padding: 0; margin: 0; display: flex;">
                <li style="margin-right: 20px;"><a href="/" style="text-decoration: none; color: #333;">Home</a></li>
                <li style="margin-right: 20px;"><a href="/about" style="text-decoration: none; color: #333;">About</a></li>
                <li style="margin-right: 20px;"><a href="/services" style="text-decoration: none; color: #333;">Services</a></li>
                <li style="margin-right: 20px;"><a href="/contact" style="text-decoration: none; color: #333;">Contact</a></li>
            </ul>
        </nav>
        <div style="flex: 1; display: flex; justify-content: flex-end;">
            <form action="/search" method="get" style="display: flex; align-items: center;">
                <input type="text" name="query" placeholder="Search..." style="padding: 5px; border: 1px solid #ccc; border-radius: 3px; margin-right: 5px;" />
                <button type="submit" style="padding: 5px 10px; border: 1px solid #ccc; background-color: #007bff; color: white; border-radius: 3px; cursor: pointer;">
                    Search
                </button>
            </form>
        </div>
    </header>
</body>
</html>
