<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Footer</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/footer.css">
    <style>
        /* Inline CSS to fix bullet points issue */
        footer {
            background-color: #f4f4f4;
            padding: 20px;
            border-top: 1px solid #ddd;
            text-align: center;
        }

        footer ul {
            list-style-type: none; /* Remove bullet points */
            padding: 0; /* Remove padding */
            margin: 0; /* Remove margin */
            display: flex; /* Display items in a row */
            justify-content: center; /* Center items horizontally */
        }

        footer li {
            margin-right: 20px; /* Space between items */
        }

        footer a {
            text-decoration: none; /* Remove underline from links */
            color: #333; /* Text color */
        }

        footer a:hover {
            text-decoration: underline; /* Add underline on hover */
        }
    </style>
</head>
<body>
    <footer>
        <ul>
            <li><a href="/about">About Us</a></li>
            <li><a href="/contact">Contact</a></li>
            <li><a href="/privacy">Privacy Policy</a></li>
            <li><a href="/terms">Terms of Service</a></li>
        </ul>
        <p>&copy; <?= date("Y"); ?> Simple Shop. All rights reserved.</p>
    </footer>
</body>
</html>
