<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Footer</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/footer.css">
    <style>
        /* Inline CSS to fix bullet points issue */
        footer {
            background-color: #f4f4f4;/* Light gray background for footer */
            padding: 20px;/* Space inside the footer */
            border-top: 1px solid #ddd;/* Light gray border at the top */
            text-align: center;/* Center text in the footer */
        }

        footer ul {
            list-style-type: none;/* Remove bullet points */
            padding: 0;/* Remove padding */
            margin: 0;/* Remove margin */
            display: flex;/* Display items in a row */
            justify-content: center;/* Center items horizontally */
        }

        footer li {
            margin-right: 20px;/* Space between items */
        }

        footer a {
            text-decoration: none;/* Remove underline from links */
            color: #333;/* Dark text color */
        }

        footer a:hover {
            text-decoration: underline;/* Add underline on hover */
        }
    </style>
</head>
<body>
    <footer>
        <ul>
            <li><a href="/aboutme.php">About Me</a></li>
            <li><a href="/contactme.php">Contact</a></li>
            <li><a href="/privacypolicy.php">Privacy Policy</a></li>
            <li><a href="/tosTerms.php">Terms of Service</a></li>
        </ul>
        <p>&copy; <?= date("Y"); ?> Cafe Simple. All rights reserved.</p>
    </footer>
</body>
</html>
