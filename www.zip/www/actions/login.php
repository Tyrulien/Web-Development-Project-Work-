<?php

Class users {
  public $firstname;

  public $lastname;

  public $email;

  public $ordersnum;

  public $pname;

  
  public function setfirstname($firstname) {
    $this->firstname = $firstname;
  }

  public function getfirstname() {
    return $this->firstname;
}
public function setlastname($lastname) {
 $this->lastname = $lastname;
}
public function getlastname() { 
    return $this->lastname;
}
public function setemail($email) {
    $this->email = $email;


}
public function getemail() {
    return $this->email;
}
public function setordersnum($ordersnum) {
    $this->ordersnum = $ordersnum;
}
public function getordersnum() {
    return $this->ordersnum;
}


public function userValidate(){
    echo "Make: " . $this->getlastname() . "<br/>";
    echo "Engine: ". $this->getordersnum() . "<br/>";
    echo "Model: ". $this->getemail() . "<br/>";


}
}

    $userA = new users();
    $userB = new users();

    // code for user A
    $userA->setfirstname('11111');
    $userA->setlastname('BMW');
    $userA->setemail('3 Series');
    $userA->setordersnum('2K40');

    // code for user B
    $userB->setfirstname('22222');
    $userB->setlastname('Mercedes-Benz');
    $userB->setemail('S Class');
    $userB->setordersnum('Turbin');


    $userA->userValidate();
    $userB->userValidate();
    ?>