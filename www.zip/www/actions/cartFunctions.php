<?php
// cartFunctins.php - Helper funcs 4 managing the cart

function addToCart($product_id, $quantity) {
    if ( isset($_SESSION['cart'] [$product_id] )) {
        $_SESSION['cart'] [$product_id] += $quantity; // Add to existng quantity
    } else {
        $_SESSION['cart'] [$product_id] = $quantity; // Add product to cart
    }
}

function removeItemFromCart($product_id) {
    if ( isset($_SESSION['cart'] [$product_id] )) {
        unset($_SESSION['cart'][$product_id]); // Remove product frm cart
    }
}

function updateCartQuantities($quantities) {
    foreach ( $quantities as $product_id => $quantity) {
        if ( isset($_SESSION['cart'][$product_id]) && $quantity > 0) {
            $_SESSION['cart'][$product_id] = $quantity; // Update quantity if greater than 0
        } elseif ($quantity == 0) {
            removeItemFromCart($product_id); // If quantity is 0, remove item
        }
    }
}

function calculateCartTotal($connection) {
    $total = 0; // Start total with 0

    foreach ( $_SESSION['cart'] as $product_id => $quantity ) {
        $stmt = $connection->prepare( "SELECT price FROM products WHERE productid = :product_id" );
        $stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT); // bind product id param
        $stmt->execute();
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($product) { // if product is found
            $total += $product['price'] * $quantity; // Add price * qty to total
        }
    }

    return $total; // return total cost
}
?>
