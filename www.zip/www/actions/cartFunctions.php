<?php
// cartFunctions.php

function addToCart($product_id, $quantity) {
    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id] += $quantity;
    } else {
        $_SESSION['cart'][$product_id] = $quantity;
    }
}

function removeItemFromCart($product_id) {
    if (isset($_SESSION['cart'][$product_id])) {
        unset($_SESSION['cart'][$product_id]);
    }
}

function updateCartQuantities($quantities) {
    foreach ($quantities as $product_id => $quantity) {
        if (isset($_SESSION['cart'][$product_id]) && $quantity > 0) {
            $_SESSION['cart'][$product_id] = $quantity;
        } elseif ($quantity == 0) {
            removeItemFromCart($product_id);
        }
    }
}

function calculateCartTotal($connection) {
    $total = 0;

    foreach ($_SESSION['cart'] as $product_id => $quantity) {
        $stmt = $connection->prepare("SELECT price FROM products WHERE productid = :product_id");
        $stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
        $stmt->execute();
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($product) {
            $total += $product['price'] * $quantity;
        }
    }

    return $total;
}
