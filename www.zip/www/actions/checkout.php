<?php
session_start();
require_once '../includes/DBconnect.php';
require_once 'cartFunctions.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    if (!isset($connection) || !$connection instanceof PDO) {
        die("Database connection is not available.");
    }

    try {
        $connection->beginTransaction();
        $stmt = $connection->prepare("INSERT INTO orders (product_id, quantity) VALUES (:product_id, :quantity)");

        foreach ($_SESSION['cart'] as $product_id => $quantity) {
            $stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
            $stmt->bindParam(':quantity', $quantity, PDO::PARAM_INT);
            $stmt->execute();
        }

        $connection->commit();
        unset($_SESSION['cart']);
        $_SESSION['cart_message'] = "Order placed successfully!";
    } catch (Exception $e) {
        $connection->rollBack();
        $_SESSION['cart_message'] = "Failed to place order: " . $e->getMessage();
    }

    header("Location: /index.php");
    exit;
} else {
    $_SESSION['cart_message'] = "Your cart is empty!";
    header("Location: /index.php");
    exit;
}
?>