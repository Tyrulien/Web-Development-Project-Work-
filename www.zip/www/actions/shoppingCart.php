<?php
session_start();
require_once '../includes/DBconnect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart</title>
    <link rel="stylesheet" href="/css/style.css"> <!-- Updated path -->
</head>
<body>
    <div class="content cart-display">
        <h1>Your Cart</h1>
        <?php if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])): ?>
            <form action="updateCart.php" method="POST">
                <?php 
                $total = 0;
                foreach ($_SESSION['cart'] as $productid => $quantity):
                    if (!isset($connection) || !$connection instanceof PDO) {
                        die("Database connection is not available.");
                    }

                    $stmt = $connection->prepare("SELECT * FROM products WHERE productid = :productid");
                    $stmt->bindParam(':productid', $productid, PDO::PARAM_INT);
                    $stmt->execute();
                    $product = $stmt->fetch(PDO::FETCH_ASSOC);

                    if (!$product) {
                        continue; // Skip if the product is not found
                    }

                    $subtotal = $product['price'] * $quantity;
                    $total += $subtotal;
                ?>
                <div class="product-details">
                    <h2><?= htmlspecialchars($product['pname']); ?></h2>
                    <p>Price: $<?= htmlspecialchars(number_format($product['price'], 2)); ?></p>
                    <p>Quantity: <?= htmlspecialchars($quantity); ?></p>
                    <p>Subtotal: $<?= htmlspecialchars(number_format($subtotal, 2)); ?></p>
                    <input type="number" name="quantities[<?= htmlspecialchars($productid); ?>]" value="<?= htmlspecialchars($quantity); ?>" min="1" class="cart-input">
                    <button type="submit" name="remove" value="<?= htmlspecialchars($productid); ?>" class="cart-button">Remove</button>
                </div>
                <?php endforeach; ?>
                <h3>Total: $<?= htmlspecialchars(number_format($total, 2)); ?></h3>
                <button type="submit" name="update" class="cart-button">Update Cart</button>
            </form>
            <a href="checkout.php" class="back-home-button">Proceed to Checkout</a>
        <?php else: ?>
            <p class="cart-message">Your cart is empty.</p>
        <?php endif; ?>
    </div>
</body>
</html>
