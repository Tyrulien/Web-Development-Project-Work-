<?php
session_start();
require_once 'cartFunctions.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['quantities'])) {
    updateCartQuantities($_POST['quantities']);
    $_SESSION['cart_message'] = "Cart updated successfully!";
    header("Location: shoppingCart.php");
    exit;
}
