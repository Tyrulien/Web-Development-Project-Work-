<?php

Class orderdetails {
  public $orderdetailsId;

  public $quantity;

  public $price;

  public $orderId;

  public $productid;


  
  public function setorderdetailsId($orderdetailsId) {
    $this->orderdetailsId = $orderdetailsId;
  }

  public function getorderdetailsId() {
    return $this->orderdetailsId;
}
public function setquantity($quantity) {
 $this->quantity = $quantity;
}
public function getquantity() { 
    return $this->quantity;
}
public function setprice($price) {
    $this->price = $price;


}
public function getprice() {
    return $this->price;
}
public function setorderId($orderId) {
    $this->orderId = $orderId;
}
public function getorderId() {
    return $this->orderId;
}
public function setproductid($productid) {
    $this->productid = $productid;
}
public function getproductid() {
    return $this->productid;
}


public function Validate(){
    echo "Make: " . $this->getquantity() . "<br/>";
    echo "quantity: " . $this->getproductid() . "<br/>";
    echo "Engine: ". $this->getorderId() . "<br/>";
    echo "Model: ". $this->getprice() . "<br/>";


}
}

    $orderdetailA = new orderdetails();
    $orderdetailB = new orderdetails();

    // code for orderdetail A
    $orderdetailA->setorderdetailsId('11111');
    $orderdetailA->setquantity('BMW');
    $orderdetailA->setproductid('45000');
    $orderdetailA->setprice('3 Series');
    $orderdetailA->setorderId('2K40');

    // code for orderdetail B
    $orderdetailB->setorderdetailsId('22222');
    $orderdetailB->setquantity('Mercedes-Benz');
    $orderdetailB->setproductid('60000');
    $orderdetailB->setprice('S Class');
    $orderdetailB->setorderId('Turbin');


    $orderdetailA->Validate();
    $orderdetailB->Validate();
    ?>