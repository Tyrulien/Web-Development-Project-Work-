<?php
session_start(); ob_start();//start session and output buffering
require_once '../includes/DBconnect.php';//include the database connection file
$pdo = $connection; require_once '../classes/user/users.php';//include the Users class file

//Check if the user is already logged in
if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
    header("Location: ../index.php");//redirect to home page if logged in
    exit;
}

$users = new Users($pdo);//create a new Users object
$error = "";//variable to store error message

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);//get the email from the form
    $password = trim($_POST['password']);//get the password from the form

    $user = $users->login($email, $password);//try to log in the user

    if ($user) {
        $_SESSION["loggedin"] = true;
        $_SESSION["userid"] = $user['userid'];//store user ID in session
        $_SESSION["username"] = $user['firstname'];//store user first name in session
        header("Location: /classes/user/profile.php");//redirect to profile page if login is successful
        exit;
    } else {
        $error = "Invalid email or password.";//store error message if login fails
    }
}
ob_end_flush();//end output buffering
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
    <style>
        /*Styling for pastel theme*/
        body {
            font-family: Arial, sans-serif;
            margin: 0; padding: 0;
            background-color: #f0f8ff;
            color: #333;
        }

        h2 {
            color: #98fb98;
            text-align: center;
            padding: 20px;
        }

        form {
            width: 300px; margin: 0 auto;
            background-color: #f5fffa;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block; margin: 10px 0 5px;
        }

        input[type="email"], input[type="password"] {
            width: 100%; padding: 10px; margin: 5px 0 15px;
            border: 1px solid #ddd; border-radius: 5px;
        }

        input[type="submit"] {
            width: 100%; padding: 10px;
            background-color: #98fb98;
            border: none; border-radius: 5px; color: #fff;
            font-size: 16px; cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #87ceeb;
        }

        .error {
            color: red; text-align: center;
        }

        .back-link {
            display: block; text-align: center; margin: 20px;
            color: #3cb371;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h2>Login</h2>
    <form action="<?= htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required>
        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required>
        <input type="submit" value="Login">
        <?php if (!empty($error)): ?>
            <p class="error"><?= htmlspecialchars($error); ?></p>
        <?php endif; ?>
    </form>
    <a class="back-link" href="../index.php">Back to Home</a>
</body>
</html>
