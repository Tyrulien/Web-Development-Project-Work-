<?php
//start the session and then clear it
session_start();
session_unset();
session_destroy();
header("Location: loginAction.php");//redirect to login page
exit;
?>
