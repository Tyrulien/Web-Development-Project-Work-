<?php

Class ordering {
  public $orderId;

  public $orderDate;

  public $orderStatus;


  public function setorderId($orderId) {
    $this->orderId = $orderId;
  }

  public function getorderId() {
    return $this->orderId;
}
public function setorderDate($orderDate) {
 $this->orderDate = $orderDate;
}
public function getorderDate() { 
    return $this->orderDate;
}
public function setorderStatus($orderStatus) {
    $this->orderStatus = $orderStatus;
}
public function getorderStatus() { 
  return $this->orderDate;
}


public function placeOrder(){
    echo "Make the order: " . $this->getorderId() . "<br/>";
    echo "Get the time: " . $this->getorderDate() . "<br/>";
    echo "Get your order status: ". $this->getorderStatus() . "<br/>";
}
}

    $orderA = new ordering();
    $orderB = new ordering();

    // code for car A
    $orderA->setorderId('1');
    $orderA->setorderDate('22:00');
    $orderA->setorderStatus('done');


    // code for car B
    $orderB->setorderId('2');
    $orderB->setorderDate('23:00');
    $orderB->setorderStatus('pending');



    $orderA->placeOrder();
    $orderB->placeOrder();

    
    ?>