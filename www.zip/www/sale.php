<?php

Class Sales {
  public $saleId;

  public $salePrice;




  public function setsaleId($saleId) {
    $this->saleId = $saleId;
  }

  public function getsaleId() {
    return $this->saleId;
}
public function setsalePrice($salePrice) {
 $this->salePrice = $salePrice;
}
public function getsalePrice() { 
    return $this->salePrice;
}


public function displaySale(){
    echo "Make: " . $this->getsalePrice() . "<br/>";
    echo "Price: " . $this->getsaleId() . "<br/>";


}
}

    $SaleA = new Sales();
    $SaleB = new Sales();

    // code for car A
    $SaleA->setsaleId('11111');
    $SaleA->setsalePrice('BMW');


    // code for car B
    $SaleB->setsaleId('22222');
    $SaleB->setsalePrice('Mercedes-Benz');



    $SaleA->displaySale();
    $SaleB->displaySale();
    ?>