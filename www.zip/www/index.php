<?php
session_start();

// Include the database connection file
require_once 'includes/DBconnect.php';

$action = filter_input(INPUT_GET, 'action');

switch ($action) {
    case 'reset':
        unset($_SESSION['counter']);
        break;
    case 'kill':
        killSession();
        break;
}

$pageHits = $_SESSION['counter'] ?? 0;
$pageHits++;
$_SESSION['counter'] = $pageHits;

function killSession() {
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
}

// Get the number of items in the cart
$cartItemCount = isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Cafe Simple</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/header.css">
    <link rel="stylesheet" href="/css/footer.css">
</head>
<body>
    <!-- Navbar Section -->
    <div class="navbar">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="public/register.php">Register</a></li>
            <li><a href="actions/loginAction.php">Login</a></li>
            <?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true): ?>
            <li class="username">Hello, <?= isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'User'; ?>!</li>
            <li><a href="logout.php">Logout</a></li>
            <li><a href="classes/user/profile.php">My Profile</a></li>
            <?php endif; ?>
            <li><a href="actions/shoppingCart.php">Cart (<?= $cartItemCount; ?>)</a></li>
        </ul>
    </div>

    <!-- Show Cart Message -->
    <?php if (isset($_SESSION['cart_message'])): ?>
    <div class="cart-message">
        <?= htmlspecialchars($_SESSION['cart_message']); ?>
    </div>
    <?php unset($_SESSION['cart_message']); // Clear the message after displaying ?>
    <script>
        // Automatically clear the message after a few seconds
        setTimeout(function() {
            document.querySelector('.cart-message').style.display = 'none';
        }, 3000);
    </script>
    <?php endif; ?>

    <div class="content">
    <h1>Welcome to Cafe Simple!</h1>
    <h1>Browse the shop for some items</h1>

    <!-- Cart Display -->
    <?php if (!empty($_SESSION['cart'])): ?>
        <h2>Your Cart</h2>
        <ul>
        <?php
        // Loop through the cart items
        foreach ($_SESSION['cart'] as $product_id => $quantity):
            // Corrected SQL query
            $stmt = $connection->prepare("SELECT pname, price FROM products WHERE productid = :id");
            $stmt->bindParam(':id', $product_id, PDO::PARAM_INT);
            $stmt->execute();
            $product = $stmt->fetch(PDO::FETCH_ASSOC);
        
            if ($product): // Ensure the product is found before displaying
        ?>
            <li><?= htmlspecialchars($product['pname']) ?> - <?= htmlspecialchars($quantity) ?> @ $<?= htmlspecialchars($product['price']) ?></li>
        <?php
            else:
                echo "<li>Product not found.</li>"; // Handle products that may have been removed
            endif;
        endforeach;
        ?>
        </ul>
    <?php endif; ?>

    <!-- Class Links Section -->
    <div class="links-container">
        <h2>Some Other Links</h2>
        <a href="classes/orders/orderdetails.php">Order Details</a>
        <a href="classes/orders/ordering.php">Ordering</a>
        <a href="products.php">Products</a>
       <!-- <a href="classes/sale/sale.php">Sale</a> -->
       <!-- <a href="classes/sale/seller.php">Seller</a> -->
      <!--  <a href="classes/user/profileUI.php">Profile UI</a> -->
        <a href="classes/user/users.php">Users</a>
    </div>

    <?php
    // Fetch and display products
    try {
        $result = $connection->query("SELECT * FROM products");
        if ($result === false) {
            throw new Exception("Error executing query: " . implode(", ", $connection->errorInfo()));
        }
    } catch (Exception $e) {
        echo "An error occurred: " . $e->getMessage();
        exit;
    }
    ?>

    <h1>Products</h1>
    <?php if ($result): ?>
        <?php while ($row = $result->fetch(PDO::FETCH_ASSOC)): ?>
            <?php
            $isInCart = isset($_SESSION['cart'][$row['productid']]) ? true : false;
            ?>
            <div class="product <?= $isInCart ? 'in-cart' : ''; ?>">
                <?php if ($isInCart): ?>
                    <div class="in-cart-badge">In Cart</div>
                <?php endif; ?>
                <h2><?= htmlspecialchars($row['pname'] ?? ''); ?></h2>
                <p>Price: $<?= htmlspecialchars($row['price'] ?? ''); ?></p>
                <p>Category: <?= htmlspecialchars($row['category'] ?? ''); ?></p>
                <p><?= htmlspecialchars($row['description'] ?? ''); ?></p>
                <img src="<?= htmlspecialchars($row['product_image'] ?? ''); ?>" alt="<?= htmlspecialchars($row['pname'] ?? ''); ?>">
                <form method="post" action="/actions/addToCart.php">
                    <input type="number" name="quantity" min="1" value="1">
                    <input type="hidden" name="product_id" value="<?= htmlspecialchars($row['productid'] ?? ''); ?>">
                    <button type="submit">Add to Cart</button>
                </form>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No products found.</p>
    <?php endif; ?>
</div>

    <!-- Including the footer -->
    <?php include "includes/footer.php"; ?>
</body>
</html>
