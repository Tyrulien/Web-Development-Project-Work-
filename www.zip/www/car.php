<?php

Class Car {
  public $carVin;

  public $carMake;

  public $carModel;

  public $carEngine;

  public $carPrice;

  public $carRegNumber;

  public function setCarVin($carVin) {
    $this->carVin = $carVin;
  }

  public function getCarVin() {
    return $this->carVin;
}
public function setCarMake($carMake) {
 $this->carMake = $carMake;
}
public function getCarMake() { 
    return $this->carMake;
}
public function setCarModel($carModel) {
    $this->carModel = $carModel;


}
public function getCarModel() {
    return $this->carModel;
}
public function setCarEngine($carEngine) {
    $this->carEngine = $carEngine;
}
public function getCarEngine() {
    return $this->carEngine;
}
public function setCarPrice($carPrice) {
    $this->carPrice = $carPrice;
}
public function getCarPrice() {
    return $this->carPrice;
}
public function setCarRegNumber($carRegNumber) {
    $this->carRegNumber = $carRegNumber;
}
public function getCarRegNumber() {
    return $this->carRegNumber;
}
public function displayCar(){
    echo "Make: " . $this->getCarMake() . "<br/>";
    echo "Price: " . $this->getCarPrice() . "<br/>";
    echo "Engine: ". $this->getCarEngine() . "<br/>";
    echo "Model: ". $this->getCarModel() . "<br/>";
    echo "RegNumber: " . $this->getCarRegNumber() . "<br/>", "<br/>";

}
}

    $carA = new Car();
    $carB = new Car();

    // code for car A
    $carA->setCarVin('11111');
    $carA->setCarMake('BMW');
    $carA->setCarPrice('45000');
    $carA->setCarModel('3 Series');
    $carA->setCarEngine('2K40');
    $carA->setCarRegNumber('B356-DF45-RT11');

    // code for car B
    $carB->setCarVin('22222');
    $carB->setCarMake('Mercedes-Benz');
    $carB->setCarPrice('60000');
    $carB->setCarModel('S Class');
    $carB->setCarEngine('Turbin');
    $carB->setCarRegNumber('BD89-DA90-RT11');


    $carA->displayCar();
    $carB->displayCar();
    ?>