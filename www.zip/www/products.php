<?php
require_once 'includes/DBconnect.php'; // Path updated to reflect new location

class Products {
    public $productid;
    public $price;
    public $category;
    public $pdescription;
    public $pname;
    public $stock; // Variable for stock quantity
    public $product_image; // Variable for product image path
    public $date; // Variable for timestamp

    // Setters and Getters for each property (all lowercase)
    public function setproductid($productid) {
        $this->productid = $productid;
    }

    public function getproductid() {
        return $this->productid;
    }

    public function setprice($price) {
        $this->price = $price;
    }

    public function getprice() {
        return $this->price;
    }

    public function setcategory($category) {
        $this->category = $category;
    }

    public function getcategory() {
        return $this->category;
    }

    public function setpdescription($pdescription) {
        $this->pdescription = $pdescription;
    }

    public function getpdescription() {
        return $this->pdescription;
    }

    public function setpname($pname) {
        $this->pname = $pname;
    }

    public function getpname() {
        return $this->pname;
    }

    public function setstock($stock) { // Setter for stock
        $this->stock = $stock;
    }

    public function getstock() { // Getter for stock
        return $this->stock;
    }

    public function setproduct_image($product_image) { // Setter for product image
        $this->product_image = $product_image;
    }

    public function getproduct_image() { // Getter for product image
        return $this->product_image;
    }

    public function setdate($date) { // Setter for the timestamp
        $this->date = $date;
    }

    public function getdate() { // Getter for the timestamp
        return $this->date;
    }

    // Method to view product details
    public function viewproductdetails() {
        echo "<div class='product-details'>";
        echo "<h2>" . htmlspecialchars($this->getpname()) . "</h2>";
        echo "<p>Price: $" . htmlspecialchars($this->getprice()) . "</p>";
        echo "<p>Category: " . htmlspecialchars($this->getcategory()) . "</p>";
        echo "<p>Description: " . htmlspecialchars($this->getpdescription()) . "</p>";
        echo "<p>Stock: " . htmlspecialchars($this->getstock()) . "</p>";

        // Assuming images are served from the root directory
        $imagePath = '/images/' . htmlspecialchars($this->getproduct_image()); // Updated to root path
        echo "<img src='" . $imagePath . "' alt='" . htmlspecialchars($this->getpname()) . "' />";

        echo "<p>Date Added: " . htmlspecialchars($this->getdate()) . "</p>";
        echo "</div>";
    }
}

// Fetching products from the database
try {
    $stmt = $connection->query("SELECT * FROM products");
    if ($stmt === false) {
        throw new Exception("Error executing query: " . implode(", ", $connection->errorInfo()));
    }
    
    // Creating and displaying product objects
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $product = new Products();
        $product->setproductid($row['productid']);
        $product->setprice($row['price']);
        $product->setpname($row['pname']);
        $product->setcategory($row['category']);
        $product->setpdescription($row['pdescription']);
        $product->setstock($row['stock']);
        $product->setproduct_image($row['product_image']);
        $product->setdate($row['date']);
        $product->viewproductdetails();
    }
} catch (Exception $e) {
    echo "An error occurred: " . $e->getMessage();
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Product List</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Path updated -->
    <link rel="stylesheet" href="products.css"> <!-- Path updated -->
</head>
<body>
    <a href="index.php" class="back-home-button">Back to Home</a> <!-- Path updated -->

    <div class="content">
        <h1>Product List</h1>
        
        <!-- Product details will be inserted here by PHP -->
    </div>

    <?php include "includes/footer.php"; ?> <!-- Path updated -->
</body>
</html>
