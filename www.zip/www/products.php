<?php

Class products {
  public $productId;

  public $price;

  public $category;

  public $pdescription;

  public $pname;

  
  public function setproductId($productId) {
    $this->productId = $productId;
  }

  public function getproductId() {
    return $this->productId;
}
public function setprice($price) {
 $this->price = $price;
}
public function getprice() { 
    return $this->price;
}
public function setcategory($category) {
    $this->category = $category;


}
public function getcategory() {
    return $this->category;
}
public function setpdescription($pdescription) {
    $this->pdescription = $pdescription;
}
public function getpdescription() {
    return $this->pdescription;
}
public function setpname($pname) {
    $this->pname = $pname;
}
public function getpname() {
    return $this->pname;
}

public function viewProductDetails(){
    echo "Make: " . $this->getprice() . "<br/>";
    echo "Price: " . $this->getpname() . "<br/>";
    echo "Engine: ". $this->getpdescription() . "<br/>";
    echo "Model: ". $this->getcategory() . "<br/>";


}
}

    $productA = new products();
    $productB = new products();

    // code for product A
    $productA->setproductId('11111');
    $productA->setprice('BMW');
    $productA->setpname('45000');
    $productA->setcategory('3 Series');
    $productA->setpdescription('2K40');

    // code for product B
    $productB->setproductId('22222');
    $productB->setprice('Mercedes-Benz');
    $productB->setpname('60000');
    $productB->setcategory('S Class');
    $productB->setpdescription('Turbin');


    $productA->viewProductDetails();
    $productB->viewProductDetails();
    ?>