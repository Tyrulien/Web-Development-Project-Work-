<?php
session_start();//Start the session

require_once '../../includes/DBconnect.php';//connect to db

require_once 'users.php';//profile.php n users.php r together

if (
    !isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) 
    {
    header("Location: loginAction.php");//Redirect to login page if not logged in
    exit;//Stop further execution
}

$pdo=$connection;//Assign the DB connection to $pdo
$users=new Users($pdo);//Create a new Users object

//user profile fetcher
$userid=$_SESSION['userid'];//Get the user ID from session
$userData = $users->getUserProfile($userid);//Fetch user profile data

if(!$userData) 
{
    echo "Can't get profile info";//Show error if profile data is not retrieved
    exit;//Stop further execution
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>User Profile</title>
    <style>
        /* Pastel look */
        body 
        {
            font-family: Arial, sans-serif;
            background-color: #f0f8ff;
            color: #333;
            padding: 20px;
        }

        .profile-container 
        {
            width: 300px;
            margin: 0 auto;
            background-color: #f5fffa;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #98fb98;
            text-align: center;
        }

        .profile-info {
            margin-bottom: 20px;
        }

        .profile-info p 
        {
            margin: 5px 0;
            color: #3cb371;
        }

        .back-link 
        {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #3cb371;
            text-decoration: none;
        }

        .back-link:hover 
        {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="profile-container">
        <h2>User Profile</h2>
        <div class="profile-info">
            <p><strong>First Name:</strong> <?= htmlspecialchars($userData['firstname']) ?></p>
            <p><strong>Last Name:</strong> <?= htmlspecialchars($userData['lastname']) ?></p>
            <p><strong>Email:</strong> <?= htmlspecialchars($userData['email']) ?></p>
        </div>
        <a class="back-link" href="../../index.php">Back to Home</a>
    </div>
</body>
</html>
