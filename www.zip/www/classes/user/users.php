<?php
ob_start();
// Includes and database connection
require_once __DIR__ . '/../../includes/DBconnect.php'; // Path to DBconnect.php relative to the current directory
$pdo = $connection;

// Users class definition
class Users {
    private $connection;

    public function __construct($pdo) {
        $this->connection = $pdo;
    }

    public function register($firstname, $lastname, $email, $password) {
        try {
            // Prepare SQL statement
            $stmt = $this->connection->prepare("INSERT INTO users (firstname, lastname, email, passwordX) VALUES (:firstname, :lastname, :email, :passwordX)");
            
            // Hash the password first and then bind it
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            // Bind parameters
            $stmt->bindParam(':firstname', $firstname);
            $stmt->bindParam(':lastname', $lastname);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':passwordX', $hashedPassword); // Use the hashed password variable
            
            // Execute statement
            $stmt->execute();
            
            return true;
        } catch (PDOException $e) {
            // Handle error
            echo "Error: " . $e->getMessage();
            return false;
        }
    }
    

    public function login($email, $password) {
        try {
            $stmt = $this->connection->prepare("SELECT * FROM users WHERE email = :email");
            $stmt->bindParam(':email', $email);
            $stmt->execute();
    
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
            if ($user && password_verify($password, $user['passwordX'])) {
                // Password is correct, return user data
                return $user;
            }
    
            return false;
} catch (PDOException $e) {
    // Log the error instead of echoing it
    error_log($e->getMessage());
    return false;
}

    }
    

    public function getUserProfile($userid) {
        try {
            $stmt = $this->connection->prepare("SELECT * FROM users WHERE userid = :userid");
            $stmt->bindParam(':userid', $userid);
            $stmt->execute();
    
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            return $user; // Return user data as an associative array
} catch (PDOException $e) {
    // Log the error instead of echoing it
    error_log($e->getMessage());
    return false;
}

    }
    
    public function getUserIdByEmail($email) {
        try {
            $stmt = $this->connection->prepare("SELECT userid FROM users WHERE email = :email");
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result ? $result['userid'] : null;
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
            return null;
        }
    }

    // New method to get all users
    public function getAllUsers() {
        try {
            $stmt = $this->connection->prepare("SELECT * FROM users");
            $stmt->execute();
            
            $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $users; // Return an array of users
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
            return [];
        }
    }
}

// Create Users instance
$users = new Users($pdo);

// Fetch all users
$allUsers = $users->getAllUsers();
ob_end_flush();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Registered Users</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f8ff;
            color: #333;
        }

        h2 {
            color: #98fb98;
            text-align: center;
            padding: 20px;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #f5fffa;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #98fb98;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .back-link {
            display: block;
            text-align: center;
            margin: 20px;
            color: #3cb371;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h2>Registered Users</h2>
    <table>
        <thead>
            <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($allUsers)): ?>
                <?php foreach ($allUsers as $user): ?>
                    <tr>
                        <td><?= htmlspecialchars($user['firstname']); ?></td>
                        <td><?= htmlspecialchars($user['lastname']); ?></td>
                        <td><?= htmlspecialchars($user['email']); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="3">No users found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <a class="back-link" href="../../index.php">Back to Home</a>
</body>
</html>
