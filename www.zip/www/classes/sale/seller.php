<?php

class seller {
    public $sellerNumber;
    public $sellerName;
    public $sellerBio;
    public $userid; // New property for the user ID
    public $date; // New property for the date

    // Setters and Getters for each property
    public function setsellerNumber($sellerNumber) {
        $this->sellerNumber = $sellerNumber;
    }

    public function getsellerNumber() {
        return $this->sellerNumber;
    }

    public function setsellerName($sellerName) {
        $this->sellerName = $sellerName;
    }

    public function getsellerName() {
        return $this->sellerName;
    }

    public function setsellerBio($sellerBio) {
        $this->sellerBio = $sellerBio;
    }

    public function getsellerBio() {
        return $this->sellerBio;
    }

    public function setUserid($userid) { // Setter for the user ID
        $this->userid = $userid;
    }

    public function getUserid() { // Getter for the user ID
        return $this->userid;
    }

    public function setDate($date) { // Setter for the date
        $this->date = $date;
    }

    public function getDate() { // Getter for the date
        return $this->date;
    }

    // Method to display seller data
    public function displaySeller() {
        echo "seller Name: " . $this->getsellerName() . "<br/>";
        echo "seller Number: " . $this->getsellerNumber() . "<br/>";
        echo "seller Bio: " . $this->getsellerBio() . "<br/>";
        echo "User ID: " . $this->getUserid() . "<br/>";
        echo "Date: " . $this->getDate() . "<br/><br/>";
    }
}

// Creating and setting seller objects
$SellerA = new seller();
$SellerB = new seller();

// Code for seller A
$SellerA->setsellerNumber(1);
$SellerA->setsellerName('Alice');
$SellerA->setsellerBio('Experienced seller in electronics.');
$SellerA->setUserid(1); // Example user ID from the users table
$SellerA->setDate(date("Y-m-d H:i:s")); // Setting the current date and time

// Code for seller B
$SellerB->setsellerNumber(2);
$SellerB->setsellerName('Bob');
$SellerB->setsellerBio('Specializes in handcrafted items.');
$SellerB->setUserid(2); // Example user ID from the users table
$SellerB->setDate(date("Y-m-d H:i:s")); // Setting the current date and time

// Display seller data
$SellerA->displaySeller();
$SellerB->displaySeller();

?>
