<?php
session_start();
require_once '../../includes/DBconnect.php'; // Ensure this path is correct

class Ordering {
    private $connection;
    private $orderId;
    private $orderDate;
    private $orderStatus;
    private $totalAmount;
    private $paymentMethod;
    private $deliveryAddress;
    private $userId;

    public function __construct($pdo, $userId) {
        $this->connection = $pdo;
        $this->userId = $userId;
    }

    // Setters and Getters
    public function setOrderId($orderId) {
        $this->orderId = $orderId;
    }

    public function getOrderId() {
        return $this->orderId;
    }

    public function setOrderDate($orderDate) {
        $this->orderDate = $orderDate;
    }

    public function getOrderDate() { 
        return $this->orderDate;
    }

    public function setOrderStatus($orderStatus) {
        $this->orderStatus = $orderStatus;
    }

    public function getOrderStatus() { 
        return $this->orderStatus;
    }

    public function setTotalAmount($totalAmount) {
        $this->totalAmount = $totalAmount;
    }

    public function getTotalAmount() {
        return $this->totalAmount;
    }

    public function setPaymentMethod($paymentMethod) {
        $this->paymentMethod = $paymentMethod;
    }

    public function getPaymentMethod() {
        return $this->paymentMethod;
    }

    public function setDeliveryAddress($deliveryAddress) {
        $this->deliveryAddress = $deliveryAddress;
    }

    public function getDeliveryAddress() {
        return $this->deliveryAddress;
    }

    public function placeOrder() {
        // Check if the cart is set and is an array
        if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart']) || empty($_SESSION['cart'])) {
            echo "<div class='cart-message'>The cart is empty or invalid. Please add items to the cart before placing an order.</div>";
            return;
        }

        // Insert order details into the database
        $stmt = $this->connection->prepare("INSERT INTO ordering (userid, orderDate, orderStatus, total_amount, payment_method, delivery_address) VALUES (:userid, :orderDate, :orderStatus, :total_amount, :payment_method, :delivery_address)");
        $stmt->bindParam(':userid', $this->userId);
        $stmt->bindParam(':orderDate', $this->orderDate);
        $stmt->bindParam(':orderStatus', $this->orderStatus);
        $stmt->bindParam(':total_amount', $this->totalAmount);
        $stmt->bindParam(':payment_method', $this->paymentMethod);
        $stmt->bindParam(':delivery_address', $this->deliveryAddress);
        $stmt->execute();

        // Get the inserted order ID
        $this->orderId = $this->connection->lastInsertId();

        // Prepare the SQL statement for inserting order details
        $stmt = $this->connection->prepare("INSERT INTO orderdetails (orderId, productid, quantity, price) VALUES (:orderId, :productid, :quantity, :price)");

        // Loop through the cart and insert each item
        foreach ($_SESSION['cart'] as $productid => $quantity) {
            // Ensure product ID and quantity are valid
            if (!is_numeric($productid) || !is_numeric($quantity) || $quantity <= 0) {
                echo "<div class='cart-message'>Invalid product ID or quantity found in the cart. Skipping invalid entry.</div>";
                continue;
            }

            // Fetch product price
            $priceStmt = $this->connection->prepare("SELECT price FROM products WHERE productid = :id");
            $priceStmt->bindParam(':id', $productid, PDO::PARAM_INT);
            $priceStmt->execute();
            $product = $priceStmt->fetch(PDO::FETCH_ASSOC);

            // Check if the product price was found
            if (!$product || !isset($product['price'])) {
                echo "<div class='cart-message'>Price not found for product ID $productid. Skipping this product.</div>";
                continue;
            }

            $price = $product['price'];

            $stmt->bindParam(':orderId', $this->orderId, PDO::PARAM_INT);
            $stmt->bindParam(':productid', $productid, PDO::PARAM_INT);
            $stmt->bindParam(':quantity', $quantity, PDO::PARAM_INT);
            $stmt->bindParam(':price', $price, PDO::PARAM_INT);
            $stmt->execute();
        }

        // Clear the cart after placing the order
        unset($_SESSION['cart']);

        // Display the order details
        echo "<div class='cart-display'>";
        echo "<h2>Order placed successfully!</h2>";
        echo "<ul>";
        echo "<li><strong>Order ID:</strong> " . htmlspecialchars($this->getOrderId()) . "</li>";
        echo "<li><strong>Order Date:</strong> " . htmlspecialchars($this->getOrderDate()) . "</li>";
        echo "<li><strong>Order Status:</strong> " . htmlspecialchars($this->getOrderStatus()) . "</li>";
        echo "<li><strong>Total Amount:</strong> $" . htmlspecialchars($this->getTotalAmount()) . "</li>";
        echo "<li><strong>Payment Method:</strong> " . htmlspecialchars($this->getPaymentMethod()) . "</li>";
        echo "<li><strong>Delivery Address:</strong> " . htmlspecialchars($this->getDeliveryAddress()) . "</li>";
        echo "</ul>";
        echo "</div>";
    }

    public function viewOrderDetails() {
        // Display order details
        echo "<div class='cart-display'>";
        echo "<h1>Order Details</h1>";
        echo "<ul>";
        echo "<li><strong>Order ID:</strong> " . htmlspecialchars($this->getOrderId()) . "</li>";
        echo "<li><strong>Order Date:</strong> " . htmlspecialchars($this->getOrderDate()) . "</li>";
        echo "<li><strong>Order Status:</strong> " . htmlspecialchars($this->getOrderStatus()) . "</li>";
        echo "<li><strong>Total Amount:</strong> $" . htmlspecialchars($this->getTotalAmount()) . "</li>";
        echo "<li><strong>Payment Method:</strong> " . htmlspecialchars($this->getPaymentMethod()) . "</li>";
        echo "<li><strong>Delivery Address:</strong> " . htmlspecialchars($this->getDeliveryAddress()) . "</li>";
        echo "</ul>";
        echo "</div>";
    }
}

// Fetch logged-in user's ID
$userId = isset($_SESSION['userid']) ? $_SESSION['userid'] : null;

if ($userId) {
    // Include the stylesheet
    echo '<link rel="stylesheet" type="text/css" href="../../css/style.css">'; // Update the path as needed

    // Pass the $connection from DBconnect.php into the Ordering class
    $order = new Ordering($connection, $userId);

    // Set order details
    $order->setOrderDate(date("Y-m-d H:i:s"));
    $order->setOrderStatus('Pending');
    $order->setTotalAmount(array_sum(array_map(function($productid, $quantity) use ($connection) {
        if (!is_numeric($productid) || !is_numeric($quantity) || $quantity <= 0) {
            return 0; // Skip invalid entries
        }
        $stmt = $connection->prepare("SELECT price FROM products WHERE productid = :id");
        $stmt->bindParam(':id', $productid, PDO::PARAM_INT);
        $stmt->execute();
        $product = $stmt->fetch(PDO::FETCH_ASSOC);
        return ($product['price'] ?? 0) * $quantity;
    }, array_keys($_SESSION['cart'] ?? []), $_SESSION['cart'] ?? [])));
    $order->setPaymentMethod('Credit Card'); // Or fetch from user input
    $order->setDeliveryAddress('123 Example Address'); // Or fetch from user input

    // Place the order
    $order->placeOrder();
} else {
    echo "<div class='cart-message'>You need to be logged in to place an order.</div>";
}
?>

<!-- Back to Home Button -->
<div class="back-home">
    <a href="../../index.php" class="back-home-button">Back to Home</a>
</div>

</body>
</html>
