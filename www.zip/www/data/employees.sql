USE 	coffeeshop;
CREATE TABLE employees (
employeeid INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
erank INT(1) NOT NULL,
firstname VARCHAR(30) NOT NULL,
lastname VARCHAR(30) NOT NULL,
email VARCHAR(50) NOT NULL,
phonenumber INT(25) NOT NULL,
date TIMESTAMP
);