USE coffeeshop;

CREATE TABLE orderdetails (
    orderdetailsId INT(11) AUTO_INCREMENT PRIMARY KEY,
    quantity INT(11) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,  -- Changed INT to DECIMAL
    orderId INT(11) UNSIGNED NOT NULL,
    productid INT(11) UNSIGNED NOT NULL, 
    discount DECIMAL(5, 2), 
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (orderId) REFERENCES ordering(orderId),
    FOREIGN KEY (productid) REFERENCES products(productid)
);
