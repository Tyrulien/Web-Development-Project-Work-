USE coffeeshop;

CREATE TABLE seller (
    sellerNumber INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY, -- Changed INT(45) to INT(11) for consistency
    sellerName VARCHAR(45) NOT NULL,
    sellerBio VARCHAR(45) NOT NULL,
    userid INT(11) UNSIGNED NOT NULL, -- Adjusted length to match the users table
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userid) REFERENCES users(userid)
);
