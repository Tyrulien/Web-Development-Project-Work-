USE coffeeshop;

CREATE TABLE profileui (     
    profileid INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(45) NOT NULL UNIQUE,
    passwordU VARCHAR(255) NOT NULL, 
    phonenumber VARCHAR(15),
    dateofbirth DATE NOT NULL,
    profile_picture VARCHAR(255), 
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
