<?php

/**
* Configuration for database connection
*
*/

// Define the host of the database server
$host = "localhost";

// Define the username for the database
$username = "root";

// Define the password for the database
$password = "";

// Define the name of the database
$dbname = "coffeeshop"; // will use later

// Create the Data Source Name string for connecting to the database
$dsn = "mysql:host=$host;dbname=$dbname"; // will use later

// Set options for the database connection
$options = array(
PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION // This helps in catching errors
);

?>
