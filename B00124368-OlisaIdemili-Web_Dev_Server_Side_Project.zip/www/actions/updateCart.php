<?php
// Start the session to use session variables for this page
session_start();

// Include the file with functions to handle cart actions
require_once 'cartFunctions.php';

// Check if the form was submitted via POST and if there are quantities in the request
if (
$_SERVER["REQUEST_METHOD"]
== "POST" &&
isset($_POST['quantities'])
) {
    // Call the function to update cart quantities with the data from the form
    updateCartQuantities($_POST['quantities']);

    // Set a session variable to show a message saying the cart was updated
    $_SESSION['cart_message'] =
    "Cart updated successfully!";

    // Redirect the user to the shopping cart page
    header("Location: shoppingCart.php");

    // Stop running the script after the redirect
    exit;
}
?>
