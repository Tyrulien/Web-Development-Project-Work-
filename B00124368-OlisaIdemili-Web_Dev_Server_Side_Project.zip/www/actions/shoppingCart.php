<?php
// Start the session to keep track of user data across different pages
session_start();

// Include the database connection file to be able to interact with the database
require_once '../includes/DBconnect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart</title>
    <!-- Link to the stylesheet for styling the page -->
    <link rel="stylesheet" href="/css/style.css"> 
</head>
<body>
    <div class="content cart-display">
        <h1>Your Cart</h1>
        <?php 
        // Check if there are items in the cart
        if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])): 
        ?>
            <!-- Form to update the cart or remove items -->
            <form action="updateCart.php" method="POST">
                <?php 
                // Initialize the total cost to 0
                $total
                 = 0;  
                // Loop through each item in the cart
                foreach ($_SESSION['cart'] as $productid => $quantity):  
                    // Check if the database connection exists and is valid
                    if 
                    (!(isset($connection) && $connection instanceof PDO)) 
                    {
                        die("No database connection."); // Stop if no database connection
                    }

                    // Get details for the current product
                    $stmt = $connection->prepare("SELECT * FROM products WHERE productid = :productid");
                    $stmt->bindParam(':productid', $productid, PDO::PARAM_INT);
                    $stmt->execute();
                    $product = $stmt->fetch(PDO::FETCH_ASSOC);

                    // Skip to the next item if the current product is not found
                    if (!$product) {
                        continue; // skip if product missing
                    }

                    // Calculate the subtotal for this product
                    $subtotal = $product['price'] * $quantity;
                    // Add this subtotal to the total cost
                    $total += $subtotal; 
                ?>
                <!-- Display details for each product in the cart -->
                <div class="product-details">
                    <h2>
                    <?= htmlspecialchars($product['pname']); ?>
                    </h2>
                    <p>Price: $<?= htmlspecialchars(number_format($product['price'], 2)); ?></p>
                    <p>Quantity: <?= htmlspecialchars($quantity); ?></p>
                    <p>Subtotal: $<?= htmlspecialchars(number_format($subtotal, 2)); ?></p>
                    <!-- Input box to change the quantity of this product -->
                    <input type="number" name="quantities[<?= htmlspecialchars($productid); ?>]" value="<?= htmlspecialchars($quantity); ?>" min="1" class="cart-input">
                    <!-- Button to remove this product from the cart -->
                    <button type="submit" name="remove" value="<?= htmlspecialchars($productid); ?>" class="cart-button">Remove</button>
                </div>
                <?php 
                endforeach; 
                ?>
                <!-- Display the total cost of all items in the cart -->
                <h3>Total: $<?= htmlspecialchars(number_format($total, 2)); ?></h3>
                <!-- Button to update the cart -->
                <button type="submit" name="update" class="cart-button">Update Cart</button>
            </form>
            <!-- Link to proceed to the checkout page -->
            <a href="checkout.php" class="back-home-button">Proceed to Checkout</a>
        <?php else: ?>
            <!-- Message shown when the cart is empty -->
            <p class="cart-message">Your cart is empty.</p>
        <?php 
        endif; 
        ?>
    </div>
</body>
</html>
