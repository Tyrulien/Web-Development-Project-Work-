<?php
require_once'../../includes/DBconnect.php';// db connection include

class OrderDetails { 
    private $orderdetailsId ;
    private $quantity ; 
    private $price;
    private $orderId; 
    private $productid;

    // Setters and Getters - methods for setting and getting properties 
    public function setOrderDetailsId($orderdetailsId) {
        $this->orderdetailsId = $orderdetailsId; 
    }

    public function getOrderDetailsId() {
        return $this->orderdetailsId; 
    } 

    public function setQuantity($quantity) {
        $this->quantity = $quantity;
    }

    public function getQuantity() {
        return $this->quantity; 
    }

    public function setPrice($price) {
        $this->price = $price; 
    } 

    public function getPrice() {
        return $this->price; 
    }

    public function setOrderId($orderId) {
        $this->orderId = $orderId; 
    }

    public function getOrderId() {
        return $this->orderId; 
    }

    public function setProductId($productid) {
        $this->productid = $productid; 
    } 

    public function getProductId() {
        return $this->productid; 
    } 

    public function validate() {
        echo "<div class='order-details'>" ;
        echo "<h2>Order Details</h2>" ;
        echo "<p><strong>Order ID:</strong>".htmlspecialchars($this->getOrderId())."</p>" ;
        echo "<p><strong>Product ID:</strong>".htmlspecialchars($this->getProductId())."</p>";
        echo "<p><strong>Quantity:</strong>".htmlspecialchars($this->getQuantity())."</p>" ;
        echo "<p><strong>Price:</strong>$".htmlspecialchars($this->getPrice())."</p>";
        echo "</div>"; 
    }
}

// Fetch order details from the db
try {
    $stmt = $connection->query("SELECT * FROM orderdetails");
    if ($stmt === false) {
        throw new Exception("Error executing query:" . implode(", ", $connection->errorInfo()));
    } 

    // Creating and displaying order detail objects
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        $orderDetail = new OrderDetails();
        $orderDetail->setOrderDetailsId($row['orderdetailsId']); 
        $orderDetail->setQuantity($row['quantity']);
        $orderDetail->setPrice($row['price']); 
        $orderDetail->setOrderId($row['orderId']); 
        $orderDetail->setProductId($row['productid']);
        $orderDetail->validate(); 
    }
}
catch (Exception $e){
    echo "An error occurred: " . $e->getMessage(); 
    exit; 
}
?>
<!DOCTYPE html>
<html lang="en">
<head> 
    <meta charset="utf-8"/>
    <meta http-equiv="x-ua-compatible" content="ie=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Order Details</title>
    <link rel="stylesheet" href="../../css/style.css"><!-- Link to the pastel theme stylesheet-->
</head>
<body>
    <div class="content">
        <h1>Order Details</h1>
        <!-- Order details will be inserted here by PHP -->
    </div>

    <!-- Back to Home Button -->
    <div class="back-home">
        <a href="../../index.php" class="back-home-button">Back to Home</a> 
    </div>

    <?php include"../../includes/footer.php";?><!-- Include footer if needed -->
</body>
</html>
