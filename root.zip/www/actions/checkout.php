<?php
session_start();// Start using session variables
require_once '../includes/DBconnect.php';// database conection

require_once 'cartFunctions.php';// Funcs to manage the cart

if ($_SERVER["REQUEST_METHOD"] 
== "POST" && isset($_SESSION['cart']) && !empty($_SESSION['cart'])) 
{
    if 
    (!isset($connection) || 
    !$connection instanceof PDO) 
    {
        die
        ("Databse conection is not availible."); // check if db connected
    }

    try 
    {
        $connection->
        beginTransaction();// start transction

        $stmt = $connection->prepare
        ("INSERT INTO orders (product_id, quantity) VALUES (:product_id, :quantity)");

        foreach($_SESSION['cart'] as $product_id=> $quantity) 
        {
            $stmt->bindParam(':product_id', 
            $product_id, PDO::PARAM_INT);// bind product ID
            $stmt->bindParam(':quantity', $quantity, PDO::PARAM_INT);// bind quantity
            $stmt->execute();// exec statmnt
        }

        $connection->commit();// Commit if all goes good
        unset($_SESSION['cart']);// Clear cart after order
        $_SESSION['cart_message'] = 
        "Order placed succesfully!";// Succes message for order
    } 
    catch (Exception $e) 
    {
        $connection->rollBack();// roll back on fail
        $_SESSION['cart_message'] = "Faild to place order: " . $e->getMessage();// Error mesage
    }

    header("Location: /index.php"); 
    exit;

} else 
{
    $_SESSION['cart_message'] = 
    "Your cart is empty!";// No items msg
    header
    ("Location: /index.php");
    exit;
}
?>
