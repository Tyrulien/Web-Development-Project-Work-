<?php
require_once '../includes/DBconnect.php';
$pdo = $connection;
require_once '../classes/user/users.php';  // Ensure this path is correct

session_start();

if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
    header("Location: ../index.php");  // Correct path to index.php
    exit;
}

$users = new Users($pdo);
$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    $user = $users->login($email, $password);  // Fetch user data

    if ($user) {
        $_SESSION["loggedin"] = true;
        $_SESSION["userid"] = $user['userid'];  // Set the session with the user ID
        $_SESSION["username"] = $user['firstname'];  // Set the username in the session
        header("Location: ../profile.php");
        exit;
    } else {
        $error = "Invalid email or password.";
    }
    
    
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
    <style>
        /* Pastel theme styling */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f8ff;
            color: #333;
        }

        h2 {
            color: #98fb98;
            text-align: center;
            padding: 20px;
        }

        form {
            width: 300px;
            margin: 0 auto;
            background-color: #f5fffa;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin: 10px 0 5px;
            color: #3cb371;
        }

        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 8px;
            margin: 5px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #98fb98;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }

        button:hover {
            background-color: #8fbc8f;
        }

        /* Link styling */
        .back-link {
            display: block;
            text-align: center;
            margin: 20px 0;
            color: #3cb371;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        /* Error message styling */
        p {
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>
    <h2>Login</h2>
    <?php if (!empty($error)): ?>
        <p><?= htmlspecialchars($error); ?></p>
    <?php endif; ?>
    <form method="POST" action="">
        <label for="email">Email:</label>
        <input type="email" name="email" required><br>

        <label for="password">Password:</label>
        <input type="password" name="password" required><br>

        <button type="submit">Login</button>
    </form>
    <a class="back-link" href="../index.php">Back to Home</a>  <!-- Correct path to index.php -->
</body>
</html>
