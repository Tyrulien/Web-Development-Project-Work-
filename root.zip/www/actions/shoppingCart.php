<?php
session_start();
require_once '../includes/DBconnect.php';

if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])):
?>
    <h1>Your Cart</h1>
    <form action="updateCart.php" method="POST">
        <?php 
        $total = 0;
        foreach ($_SESSION['cart'] as $productid => $quantity):
            if (!isset($connection) || !$connection instanceof PDO) {
                die("Database connection is not available.");
            }

            $stmt = $connection->prepare("SELECT * FROM products WHERE id = :productid");
            $stmt->bindParam(':productid', $productid, PDO::PARAM_INT);
            $stmt->execute();
            $product = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$product) {
                continue; // Skip if the product is not found
            }

            $subtotal = $product['price'] * $quantity;
            $total += $subtotal;
        ?>
            <div>
                <h2><?= htmlspecialchars($product['pname']); ?></h2>
                <p>Price: $<?= htmlspecialchars(number_format($product['price'], 2)); ?></p>
                <p>Quantity: <?= htmlspecialchars($quantity); ?></p>
                <p>Subtotal: $<?= htmlspecialchars(number_format($subtotal, 2)); ?></p>
                <input type="number" name="quantities[<?= htmlspecialchars($productid); ?>]" value="<?= htmlspecialchars($quantity); ?>" min="1">
                <button type="submit" name="remove" value="<?= htmlspecialchars($productid); ?>">Remove</button>
            </div>
        <?php endforeach; ?>
        <h3>Total: $<?= htmlspecialchars(number_format($total, 2)); ?></h3>
        <button type="submit" name="update">Update Cart</button>
    </form>
    <a href="checkout.php">Proceed to Checkout</a>
<?php else: ?>
    <p>Your cart is empty.</p>
<?php endif; ?>
