<?php
session_start();// Start the session to use session variables
require_once 'cartFunctions.php';// Include the functions needed to handle cart operations

if ($_SERVER["REQUEST_METHOD"]
== "POST") 
{

$product_id=
filter_input(INPUT_POST, 
'product_id', FILTER_VALIDATE_INT);// Get the product ID from the POST data and make sure it's a valid integer
$quantity=filter_input(
INPUT_POST, 'quantity', 
FILTER_VALIDATE_INT);// Get the quantity from the POST data and make sure it's a valid integer

// Check valid product ID && qty
if ($product_id && $quantity && 
$quantity > 0) { 
addToCart($product_id, $quantity);// Add the item to the cart with the specified quantity
    //Item added msg
$_SESSION['cart_message'] = 
"Item added to cart!";// Set a message indicating the item was added successfully
} 
else {
$_SESSION['cart_message'] =
"Invalid product or quantity.";// Set a message indicating there was an issue with the product ID or quantity
}

header("Location: /index.php");// Redirect to the homepage after processing
exit;// Stop the script to ensure no further code is executed

}
?>
