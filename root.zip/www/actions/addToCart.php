<?php
session_start();
require_once 'cartFunctions.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_id = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
    $quantity = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT);

    // Check for valid product ID and quantity
    if ($product_id && $quantity && $quantity > 0) {
        addToCart($product_id, $quantity);
        $_SESSION['cart_message'] = "Item added to cart!";
    } else {
        $_SESSION['cart_message'] = "Invalid product or quantity.";
    }

    header("Location: /index.php");
    exit;
}
