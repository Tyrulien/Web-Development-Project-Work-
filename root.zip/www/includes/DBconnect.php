<?php
require_once 'config.php'; // grabbin the login values

// Establing a connection to the database
try {
$connection = new PDO($dsn, $username, $password,
$options);
//DB connected, yay!! (commented out)

// to Catch errors
} catch (\PDOException $e) {
throw new \PDOException($e->getMessage(), (int)$e->getCode());
}
?>
