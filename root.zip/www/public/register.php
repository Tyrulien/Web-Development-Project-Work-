<?php
require_once '../includes/DBconnect.php'; // Correct path to DBconnect.php
$pdo = $connection;
include '../classes/user/users.php'; // Correct path to Users.php

$users = new Users($pdo);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $firstname = trim($_POST['firstname']);
    $lastname = trim($_POST['lastname']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);

    // Basic validation
    if (empty($firstname) || empty($lastname) || empty($email) || empty($password)) {
        $error = "Please fill in all fields.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        if ($users->register($firstname, $lastname, $email, $password)) {
            session_start();
            $_SESSION['loggedin'] = true;
            $_SESSION['userid'] = $users->getUserIdByEmail($email); // Store user ID in session
            $_SESSION['username'] = $firstname; // Store username (or any identifier) in session
            header("Location: ../index.php"); // Redirect to the main page in C:\laragon\www
            exit;
        } else {
            $error = "Registration failed. Email might be in use.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Register</title>
    <style>
        /* Pastel theme styling */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f8ff;
            color: #333;
        }

        h2 {
            color: #98fb98;
            text-align: center;
            padding: 20px;
        }

        form {
            width: 300px;
            margin: 0 auto;
            background-color: #f5fffa;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin: 10px 0 5px;
            color: #3cb371;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 8px;
            margin: 5px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #98fb98;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }

        button:hover {
            background-color: #8fbc8f;
        }

        /* Link styling */
        .back-link {
            display: block;
            text-align: center;
            margin: 20px 0;
            color: #3cb371;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        /* Error message styling */
        p {
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>
    <h2>Register</h2>
    <?php if (!empty($error)): ?>
        <p><?= htmlspecialchars($error); ?></p>
    <?php endif; ?>
    <form method="POST" action="">
        <label for="firstname">First Name:</label>
        <input type="text" name="firstname" required><br>

        <label for="lastname">Last Name:</label>
        <input type="text" name="lastname" required><br>

        <label for="email">Email:</label>
        <input type="email" name="email" required><br>

        <label for="password">Password:</label>
        <input type="password" name="password" required><br>

        <label for="confirm_password">Confirm Password:</label>
        <input type="password" name="confirm_password" required><br>

        <button type="submit">Register</button>
    </form>
    <a class="back-link" href="../index.php">Back to Home</a> <!-- Corrected link to index.php -->
</body>
</html>
