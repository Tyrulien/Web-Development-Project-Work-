USE coffeeshop;

CREATE TABLE sale (
    saleId INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
    salePrice INT(11) NOT NULL,
    sellerNumber INT(11) UNSIGNED NOT NULL, 
    productid INT(11) UNSIGNED NOT NULL, 
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sellerNumber) REFERENCES seller(sellerNumber),
    FOREIGN KEY (productid) REFERENCES products(productid)
);
