USE coffeeshop;

CREATE TABLE users (
    userid INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    firstname VARCHAR(30) NOT NULL,
    lastname VARCHAR(30) NOT NULL,
    passwordX VARCHAR(255) NOT NULL,
    email VARCHAR(50) NOT NULL UNIQUE,
    ordersnum VARCHAR(200),
    address VARCHAR(255), 
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
