-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping data for table coffeeshop.orderdetails: ~32 rows (approximately)
INSERT INTO `orderdetails` (`orderdetailsId`, `quantity`, `price`, `orderId`, `productid`, `discount`, `date`) VALUES
	(1, 1, 1800.00, 3, 3, NULL, '2024-08-25 18:58:13'),
	(2, 3, 1200.00, 3, 2, NULL, '2024-08-25 18:58:13'),
	(3, 3, 1500.00, 3, 1, NULL, '2024-08-25 18:58:13'),
	(4, 1, 1500.00, 4, 1, NULL, '2024-08-26 20:16:26'),
	(5, 1, 1200.00, 4, 2, NULL, '2024-08-26 20:16:26'),
	(6, 1, 1800.00, 4, 3, NULL, '2024-08-26 20:16:26'),
	(7, 1, 1500.00, 5, 1, NULL, '2024-08-26 20:17:13'),
	(8, 1, 1500.00, 6, 1, NULL, '2024-08-26 20:20:06'),
	(9, 1, 1200.00, 6, 2, NULL, '2024-08-26 20:20:06'),
	(10, 1, 1800.00, 6, 3, NULL, '2024-08-26 20:20:06'),
	(11, 1, 1800.00, 7, 3, NULL, '2024-08-26 21:01:26'),
	(12, 1, 1200.00, 7, 2, NULL, '2024-08-26 21:01:26'),
	(13, 1, 1500.00, 7, 1, NULL, '2024-08-26 21:01:26'),
	(14, 5, 1800.00, 8, 3, NULL, '2024-08-26 22:57:20'),
	(15, 2, 1200.00, 8, 2, NULL, '2024-08-26 22:57:20'),
	(16, 2, 1500.00, 8, 1, NULL, '2024-08-26 22:57:20'),
	(17, 5, 1800.00, 9, 3, NULL, '2024-08-26 22:58:16'),
	(18, 5, 1200.00, 10, 2, NULL, '2024-08-27 18:29:34'),
	(19, 3, 1500.00, 10, 1, NULL, '2024-08-27 18:29:34'),
	(20, 6, 1800.00, 10, 3, NULL, '2024-08-27 18:29:34'),
	(21, 1, 1200.00, 11, 2, NULL, '2024-08-27 18:35:51'),
	(22, 1, 1500.00, 11, 1, NULL, '2024-08-27 18:35:51'),
	(23, 1, 1800.00, 11, 3, NULL, '2024-08-27 18:35:51'),
	(24, 1, 1800.00, 12, 3, NULL, '2024-08-27 21:14:38'),
	(25, 1, 1200.00, 12, 2, NULL, '2024-08-27 21:14:38'),
	(26, 1, 1500.00, 12, 1, NULL, '2024-08-27 21:14:38'),
	(27, 1, 1800.00, 13, 3, NULL, '2024-08-27 21:53:15'),
	(28, 1, 1200.00, 13, 2, NULL, '2024-08-27 21:53:15'),
	(29, 1, 1500.00, 13, 1, NULL, '2024-08-27 21:53:15'),
	(30, 1, 1200.00, 14, 2, NULL, '2024-08-29 22:24:02'),
	(31, 1, 1500.00, 14, 1, NULL, '2024-08-29 22:24:02'),
	(32, 1, 1800.00, 14, 3, NULL, '2024-08-29 22:24:02');

-- Dumping data for table coffeeshop.ordering: ~12 rows (approximately)
INSERT INTO `ordering` (`orderId`, `orderDate`, `orderStatus`, `total_amount`, `payment_method`, `delivery_address`, `userid`, `date`) VALUES
	(1, '2024-08-25 18:38:33', 'Pending', 9900.00, 'Credit Card', '123 Example Address', 10, '2024-08-25 18:38:33'),
	(2, '2024-08-25 18:50:33', 'Pending', 9900.00, 'Credit Card', '123 Example Address', 10, '2024-08-25 18:50:33'),
	(3, '2024-08-25 18:58:13', 'Pending', 9900.00, 'Credit Card', '123 Example Address', 10, '2024-08-25 18:58:13'),
	(4, '2024-08-26 20:16:25', 'Pending', 4500.00, 'Credit Card', '123 Example Address', 17, '2024-08-26 20:16:26'),
	(5, '2024-08-26 20:17:13', 'Pending', 1500.00, 'Credit Card', '123 Example Address', 17, '2024-08-26 20:17:13'),
	(6, '2024-08-26 20:20:06', 'Pending', 4500.00, 'Credit Card', '123 Example Address', 18, '2024-08-26 20:20:06'),
	(7, '2024-08-26 21:01:26', 'Pending', 4500.00, 'Credit Card', '123 Example Address', 18, '2024-08-26 21:01:26'),
	(8, '2024-08-26 22:57:19', 'Pending', 14400.00, 'Credit Card', '123 Example Address', 18, '2024-08-26 22:57:19'),
	(9, '2024-08-26 22:58:15', 'Pending', 9000.00, 'Credit Card', '123 Example Address', 18, '2024-08-26 22:58:15'),
	(10, '2024-08-27 18:29:34', 'Pending', 21300.00, 'Credit Card', '123 Example Address', 18, '2024-08-27 18:29:34'),
	(11, '2024-08-27 18:35:51', 'Pending', 4500.00, 'Credit Card', '123 Example Address', 18, '2024-08-27 18:35:51'),
	(12, '2024-08-27 21:14:38', 'Pending', 4500.00, 'Credit Card', '123 Example Address', 12, '2024-08-27 21:14:38'),
	(13, '2024-08-27 21:53:15', 'Pending', 4500.00, 'Credit Card', '123 Example Address', 12, '2024-08-27 21:53:15'),
	(14, '2024-08-29 22:24:02', 'Pending', 4500.00, 'Credit Card', '123 Example Address', 12, '2024-08-29 22:24:02');

-- Dumping data for table coffeeshop.payment: ~0 rows (approximately)

-- Dumping data for table coffeeshop.products: ~3 rows (approximately)
INSERT INTO `products` (`productid`, `price`, `category`, `pdescription`, `pname`, `stock`, `product_image`, `date`) VALUES
	(1, 1500, 1, 'Delicious dark roast coffee', 'Dark Roast', 50, 'images/dark_roast.png', '2024-08-17 20:27:40'),
	(2, 1200, 2, 'Creamy vanilla latte', 'Vanilla Latte', 30, 'images/vanilla_latte.png', '2024-08-17 20:27:40'),
	(3, 1800, 1, 'Premium blend espresso', 'Espresso', 20, 'images/espresso.png', '2024-08-17 20:27:40');

-- Dumping data for table coffeeshop.profileui: ~0 rows (approximately)

-- Dumping data for table coffeeshop.sale: ~0 rows (approximately)

-- Dumping data for table coffeeshop.seller: ~0 rows (approximately)

-- Dumping data for table coffeeshop.users: ~16 rows (approximately)
INSERT INTO `users` (`userid`, `firstname`, `lastname`, `passwordX`, `email`, `ordersnum`, `address`, `date`) VALUES
	(1, 'Olisa', 'Idemili', '$2y$10$9xjRoloRSqOO7.ParhOj3ujTrmJE8vXSuxJdmzd3F9fFInge78Iqi', 'myemail@gmail.com', NULL, NULL, '2024-08-22 18:23:14'),
	(2, 'Token', 'Admin', '$2y$10$KAPNyoQOr4PxkfzJk73hueefGZeU.PZBqwXPUIsmxudoLJIa2Uvku', 'admintoken@gmail.com', NULL, NULL, '2024-08-22 18:29:23'),
	(3, 'han', 'fav', '$2y$10$WR9BmIjHXFhzosZdvPVK5eBG813VhWAn9S6mFsfT.FttQ0dn7Uq8C', 'timb@gmail.com', NULL, NULL, '2024-08-22 18:29:58'),
	(4, 'han', 'fav', '$2y$10$QKZ52hdX19GjfUfqiD6.ZuBqtRrYzHXroPPRujQilMjToIzu7LdUu', 'gurk@gmail.com', NULL, NULL, '2024-08-22 18:44:06'),
	(5, 'Gang', 'Orc', '$2y$10$Scz.ukBTmqE7CpsqgMxVYe9oqOLEhsk5h7BjgWkMTKKMNBQmdAEoi', 'gangorc@gmail.com', NULL, NULL, '2024-08-23 12:03:29'),
	(6, 'timing', 'proxy', '$2y$10$FeYSCEAOB2pTZ7WHfzTtXOYE6IwHVEjiiC3/.eCcK0pSnsewTEEUC', 'timingproxy@gmail.com', NULL, NULL, '2024-08-23 12:11:17'),
	(7, 'time', 'aqw', '$2y$10$/ghipEnuik/GLWaWmqwyN.FvD3sH9eyGJobiqtPQ./dbPRWiBdA/i', 'timeaqw@gmail.com', NULL, NULL, '2024-08-23 12:22:46'),
	(8, 'Hanny', 'Erb', '$2y$10$S0IgRQbdptT7fzqY0qzOEOy7wloP2AviKh/BNhgyTgcGvHsdZ7wRK', 'hannyerb@gmail.com', NULL, NULL, '2024-08-23 12:36:13'),
	(9, 'hally', 'amberg', '$2y$10$r8Nrhp2CF2kVdeZdEs/eH.J6yld9XT3T8QJzpKLpeu7N9eGlLuKsC', 'hallyamberg@gmail.com', NULL, NULL, '2024-08-23 13:02:31'),
	(10, 'Hane', 'Bane', '$2y$10$Ny7zt9zelg.ejiige348BuboP4YA.spkr.ay/rIuqhNcNbzG6qXk6', 'hanebane@gmail.com', NULL, NULL, '2024-08-23 14:10:05'),
	(11, 'Abby', 'Burginham', '$2y$10$qlGwPmc3K0GNkWyij5nAduhbntNNNMG1dghaQzq9q.vMBmLjJQXTy', 'abbyburg@gmail.com', NULL, NULL, '2024-08-26 14:24:23'),
	(12, 'Pepper', 'Mint', '$2y$10$gvZN1h/hT4a32ZLdBtqIr.7aL.GVY/AWbe.LRpF47oybRPSSa0kdK', 'peppermint@gmail.com', NULL, NULL, '2024-08-26 14:27:43'),
	(13, 'Tanky', 'Rock', '$2y$10$w4GRCfFin0vBkAQhBfkW3OLUpatejYF422rkrvqWnmrZGy3LDtDP.', 'tankyrock@gmail.com', NULL, NULL, '2024-08-26 16:56:41'),
	(14, 'Pilling', 'Target', '$2y$10$VQgAW5Tk7M3TepJve7ESBOMJOyoIHJ8iVwjusSnrGDBOyictleEjK', 'pillingtarget@gmail.com', NULL, NULL, '2024-08-26 16:57:56'),
	(15, 'Nappy', 'Horn', '$2y$10$BKC7LGYJ9tRTLOBe9Bj.4OBCBwDpluEyu.livbKoYFhLNfe3vlWH2', 'nappyhorn@gmail.com', NULL, NULL, '2024-08-26 18:15:13'),
	(16, 'Rhino', 'Horn', '$2y$10$R9yaWWqKoKLY1/tL1QSNo.sz2WUKgTOi99ECROomyVSbNJv80W0qW', 'rhinohorn@gmail.com', NULL, NULL, '2024-08-26 18:18:19'),
	(17, 'Rapid', 'Snake', '$2y$10$75KLdPXLoJBpVapQ7Zt5zOZ9LbaVS3tjl0nPD.cTu4rxG/mLtq/Na', 'rapidsnake@gmail.com', NULL, NULL, '2024-08-26 19:20:07'),
	(18, 'Parry', 'King', '$2y$10$8c3YHjK7OqUgbU.fiMpGS.EEgSAGG.L56okEtGohBRj4hZdXqe2/G', 'parryking@gmail.com', NULL, NULL, '2024-08-26 20:18:32');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
