USE coffeeshop;

CREATE TABLE ordering (
    orderId INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    orderDate DATETIME NOT NULL,
    orderStatus VARCHAR(55) NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL, 
    payment_method VARCHAR(30), 
    delivery_address VARCHAR(255), 
    userid INT(11) NOT NULL, 
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
