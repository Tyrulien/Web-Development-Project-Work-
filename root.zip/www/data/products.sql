USE coffeeshop;

CREATE TABLE products (
    productid INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    price INT(11) NOT NULL,
    category INT(11) NOT NULL,
    pdescription VARCHAR(500) NOT NULL,
    pname VARCHAR(30) NOT NULL,
    stock INT(11) DEFAULT 0, 
    product_image VARCHAR(255), 
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


INSERT INTO products (price, category, pdescription, pname, stock, product_image, DATE)
VALUES (1500, 1, 'Delicious dark roast coffee', 'Dark Roast', 50, 'images/dark_roast.png', NOW()),
       (1200, 2, 'Creamy vanilla latte', 'Vanilla Latte', 30, 'images/vanilla_latte.png', NOW()),
       (1800, 1, 'Premium blend espresso', 'Espresso', 20, 'images/espresso.png', NOW());
