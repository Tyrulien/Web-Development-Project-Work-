<?php
session_start();//Begin the session

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Terms of Service</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/header.css">
    <link rel="stylesheet" href="/css/footer.css">
</head>
<body>
    <!--Navbar-->
    <div class="navbar">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="public/register.php">Register</a></li>
            <li><a href="public/loginAction.php">Login</a></li>
            <?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true): ?>
            <li class="username">Hello, <?= isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'User'; ?>!</li>
            <li><a href="public/logout.php">Logout</a></li>
            <?php endif; ?>
        </ul>
    </div>

    <!--Terms of Service Content-->
    <div class="content">
        <h1>Terms of Service</h1>
        <p>
            This is my Terms of Service page. These terms and conditions show what you can and can't do on my website.
        </p>
        <h2>1. Introduction</h2>
        <p>
            By using my site, you agree to only use my site how it was intended and to not misuse it.
        </p>
        <h2>2. Your Obligations as the User</h2>
        <p>
           You must agree to use my website lawfully.
        </p>
        <h2>3. Changes to My Terms</h2>
        <p>
            At any given time I may change my terms of use and you will be binded by that terms of use for how you may use my website.
        </p>
        <h2>4. Contacting Me</h2>
        <p>
            If you have any questions about my terms, then contact me at:
            <br>Email: b00124368@mytudublin.ie
        </p>
    </div>

    <!--Footer-->
    <?php include "includes/footer.php"; ?>
</body>
</html>
