<?php
session_start();//Begin the session

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Privacy Policy</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/header.css">
    <link rel="stylesheet" href="/css/footer.css">
</head>
<body>
    <!--Navbar-->
    <div class="navbar">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="aboutme.php">About Me</a></li>
            <li><a href="contactme.php">Contact Me</a></li>
            <?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true): ?>
            <li class="username">Hello, <?= isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'User'; ?>!</li>
            <li><a href="public/logout.php">Logout</a></li>
            <?php endif; ?>
        </ul>
    </div>

    <!--Privacy Policy Content-->
    <div class="content">
        <h1>Privacy Policy</h1>
        <p>
            Your data is fully safe and encrypted on my website
        </p>
        <h2>1. Information storing</h2>
        <p>
            The information you input in the register form is securely stored in a database
        </p>
        <h2>2. How your info may be used</h2>
        <p>
            The information I collect may be used to:
            <ul>
                <li>Provide better customer support</li>
                <li>I might use it to improve my websites services</li>
            </ul>
        </p>
        <h2>3. Cases where I may disclose your info</h2>
        <p>
            I may disclose your information to third parties depending on if not:
            <ul>
                <li>To comply with the law if necessary</li>
                <li>To protect and defend myself against lies</li>
                <li>To prevent or to investigate any possible wrongdoings involving my site</li>
            </ul>
        </p>
        <h2>4. Security</h2>
        <p>
            I value the trust you put in me when using my website and I want to ensure to you that all purchases made on my site are secure and encrypted and secure to the best of my ability.
        </p>
        <h2>5. I may change my policy</h2>
        <p>
            I may change my privacy policy, but I will let you know whenever that happens.
        </p>
        <h2>6. Contact</h2>
        <p>
            If you have any questions about this Privacy Policy, please contact me at:
            <br>Email: b00124368@mytudublin.ie
        </p>
    </div>

    <!--Footer-->
    <?php include "includes/footer.php"; ?>
</body>
</html>
