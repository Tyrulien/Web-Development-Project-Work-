<?php
session_start();//Begin the session

//Load DB connection file
require_once 'includes/DBconnect.php';//Ensure DB is connected

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Contact Me</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/header.css">
    <link rel="stylesheet" href="/css/footer.css">
</head>
<body>
    <!--Navbar-->
    <div class="navbar">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="aboutme.php">About Me</a></li>
            <li><a href="contactme.php">Contact Me</a></li>
            <?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true): ?>
            <li class="username">Hello, <?= isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'User'; ?>!</li>
            <li><a href="public/logout.php">Logout</a></li>
            <?php endif; ?>
        </ul>
    </div>

    <!--Contact Form-->
    <div class="content">
        <h1>Contact Me</h1>
        
        <p>If there are any problems with my site. Please use my contact details below to message me.</p>
        
        <form action="process_contact.php" method="post">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
            </div>
            
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            
            <div class="form-group">
                <label for="message">Message:</label>
                <textarea id="message" name="message" rows="5" required></textarea>
            </div>
            
            <button type="submit">Send Message</button>
        </form>
        
        <h2>My Contact Info</h2>
        <p>My Email: b00124368@mytudublin.ie</p>
        <p>My Phone: 000000000</p>
        <p>My Address: My Address is</p>
    </div>

    <!--Footer-->
    <?php include "includes/footer.php"; ?>
</body>
</html>
