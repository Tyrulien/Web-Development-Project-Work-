<?php
session_start();//Begin the session

//Load DB connection file
require_once 'includes/DBconnect.php';//Ensure DB is connected

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>About Me</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/header.css">
    <link rel="stylesheet" href="/css/footer.css">
</head>
<body>
    <!--Navbar-->
    <div class="navbar">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="aboutme.php">About Me</a></li>
            <li><a href="contactme.php">Contact Me</a></li>
            <?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true): ?>
            <li class="username">Hello, <?= isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'User'; ?>!</li>
            <li><a href="public/logout.php">Logout</a></li>
            <?php endif; ?>
        </ul>
    </div>

    <!--About Me Content-->
    <div class="content">
        <h1>About Me</h1>
        <div class="profile">
            <p>Hello! My name is Olisa. This is my web development server-side project.</p>
            <p>This is my project that I have made so I can pass my one outstanding module so I can move to third year after failing two times because of lack of effort. This time I have put a lot more effort so i can finally pass year two.</p>
        </div>
    </div>

    <!--Footer-->
    <?php include "includes/footer.php"; ?>
</body>
</html>
