<?php

class products {
    public $productid;
    public $price;
    public $category;
    public $pdescription;
    public $pname;
    public $stock; // Variable for stock quantity
    public $product_image; // Variable for product image path
    public $date; // Variable for timestamp

    // Setters and Getters for each property (all lowercase)
    public function setproductid($productid) {
        $this->productid = $productid;
    }

    public function getproductid() {
        return $this->productid;
    }

    public function setprice($price) {
        $this->price = $price;
    }

    public function getprice() {
        return $this->price;
    }

    public function setcategory($category) {
        $this->category = $category;
    }

    public function getcategory() {
        return $this->category;
    }

    public function setpdescription($pdescription) {
        $this->pdescription = $pdescription;
    }

    public function getpdescription() {
        return $this->pdescription;
    }

    public function setpname($pname) {
        $this->pname = $pname;
    }

    public function getpname() {
        return $this->pname;
    }

    public function setstock($stock) { // Setter for stock
        $this->stock = $stock;
    }

    public function getstock() { // Getter for stock
        return $this->stock;
    }

    public function setproduct_image($product_image) { // Setter for product image
        $this->product_image = $product_image;
    }

    public function getproduct_image() { // Getter for product image
        return $this->product_image;
    }

    public function setdate($date) { // Setter for the timestamp
        $this->date = $date;
    }

    public function getdate() { // Getter for the timestamp
        return $this->date;
    }

    // Method to view product details
    public function viewproductdetails() {
        echo "Product ID: " . $this->getproductid() . "<br/>";
        echo "Product Name: " . $this->getpname() . "<br/>";
        echo "Price: $" . $this->getprice() . "<br/>";
        echo "Category: " . $this->getcategory() . "<br/>";
        echo "Description: " . $this->getpdescription() . "<br/>";
        echo "Stock: " . $this->getstock() . "<br/>";
        echo "Product Image: " . $this->getproduct_image() . "<br/>";
        echo "Date Added: " . $this->getdate() . "<br/>";
    }
}

// Creating and setting product objects
$productA = new products();
$productB = new products();

// Code for product A
$productA->setproductid(1);
$productA->setprice(1500);
$productA->setpname('Dark Roast Coffee');
$productA->setcategory(1); // Assuming category 1 is for "Hot Drinks"
$productA->setpdescription('Delicious dark roast coffee, perfect for your morning routine.');
$productA->setstock(100); // Example stock quantity
$productA->setproduct_image('images/dark_roast.jpg'); // Example image path
$productA->setdate(date("Y-m-d H:i:s")); // Setting the current date and time

// Code for product B
$productB->setproductid(2);
$productB->setprice(1200);
$productB->setpname('Vanilla Latte');
$productB->setcategory(2); // Assuming category 2 is for "Specialty Drinks"
$productB->setpdescription('Creamy vanilla latte, a smooth treat for any time of day.');
$productB->setstock(50); // Example stock quantity
$productB->setproduct_image('images/vanilla_latte.jpg'); // Example image path
$productB->setdate(date("Y-m-d H:i:s")); // Setting the current date and time

// Display product details
$productA->viewproductdetails();
$productB->viewproductdetails();
?>
