<?php
// including the database connection
session_start();
require_once '../../includes/DBconnect.php'; 

class Ordering {
private $connection;
private $orderId;
private $orderDate;
private $orderStatus;
private $totalAmount;
private $paymentMethod;
private $deliveryAddress;
private $userId;

public function __construct($pdo, $userId){
$this->connection = $pdo;
$this->userId = $userId;
}

// id setter/getter
public function setOrderId($orderId){
$this->orderId = $orderId; 
}

public function getOrderId(){
return $this->orderId;
}

public function setOrderDate($orderDate){ 
$this->orderDate = $orderDate; 
}

public function getOrderDate(){
return $this->orderDate; 
}

public function setOrderStatus($orderStatus){
$this->orderStatus = $orderStatus;
}

public function getOrderStatus() {
return $this->orderStatus;
}

public function setTotalAmount($totalAmount){
$this->totalAmount = $totalAmount; 
}

public function getTotalAmount(){
return $this->totalAmount;
}

public function setPaymentMethod($paymentMethod){ 
$this->paymentMethod = $paymentMethod;
}

public function getPaymentMethod() { 
return $this->paymentMethod;
}

public function setDeliveryAddress($deliveryAddress) {
$this->deliveryAddress = $deliveryAddress;
}

public function getDeliveryAddress(){
return $this->deliveryAddress;
}

public function placeOrder(){
// check if cart is empty or invalid
if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart']) || empty($_SESSION['cart'])) { 
echo "<div class='cart-message'>Your cart is empty or not valid. Add stuff first!</div>";
return; 
}

// insert order into the database
$stmt = $this->connection->prepare("INSERT INTO ordering (userid, orderDate, orderStatus, total_amount, payment_method, delivery_address) VALUES (:userid, :orderDate, :orderStatus, :total_amount, :payment_method, :delivery_address)");
$stmt->bindParam(':userid', $this->userId);
$stmt->bindParam(':orderDate', $this->orderDate);
$stmt->bindParam(':orderStatus', $this->orderStatus);
$stmt->bindParam(':total_amount', $this->totalAmount);
$stmt->bindParam(':payment_method', $this->paymentMethod);
$stmt->bindParam(':delivery_address', $this->deliveryAddress);
$stmt->execute();

$this->orderId = $this->connection->lastInsertId();

// insert each item in details table
$stmt = $this->connection->prepare("INSERT INTO orderdetails (orderId, productid, quantity, price) VALUES (:orderId, :productid, :quantity, :price)");

foreach ($_SESSION['cart'] as $productid => $quantity) {
// check if product ID and quantity are valid
if (!is_numeric($productid) || !is_numeric($quantity) || $quantity <= 0) { 
    echo "<div class='cart-message'>Something's wrong with ID or qty, skipping.</div>";
    continue; 
}

// get price of the product
$priceStmt = $this->connection->prepare("SELECT price FROM products WHERE productid = :id");
$priceStmt->bindParam(':id', $productid, PDO::PARAM_INT);
$priceStmt->execute();
$product = $priceStmt->fetch(PDO::FETCH_ASSOC);

if (!$product || !isset($product['price'])) {
echo "<div class='cart-message'>Price missing for ID $productid. Skipping...</div>";
continue; 
}

$price = $product['price'];

$stmt->bindParam(':orderId', $this->orderId, PDO::PARAM_INT);
$stmt->bindParam(':productid', $productid, PDO::PARAM_INT);
$stmt->bindParam(':quantity', $quantity, PDO::PARAM_INT);
$stmt->bindParam(':price', $price, PDO::PARAM_INT);
$stmt->execute();
}

// clear the cart
unset($_SESSION['cart']);

// display order confirmation
echo "<div class='cart-display'>";
echo "<h2>Order placed!</h2>";
echo "<ul>";
echo "<li><strong>Order ID:</strong> " . htmlspecialchars($this->getOrderId()) . "</li>";
echo "<li><strong>Date:</strong> " . htmlspecialchars($this->getOrderDate()) . "</li>";
echo "<li><strong>Status:</strong> " . htmlspecialchars($this->getOrderStatus()) . "</li>";
echo "<li><strong>Total:</strong> $" . htmlspecialchars($this->getTotalAmount()) . "</li>";
echo "<li><strong>Payment:</strong> " . htmlspecialchars($this->getPaymentMethod()) . "</li>";
echo "<li><strong>Delivery:</strong> " . htmlspecialchars($this->getDeliveryAddress()) . "</li>";
echo "</ul>";
echo "</div>";
}

public function viewOrderDetails(){
// displaying the order details
echo "<div class='cart-display'>";
echo "<h1>Order Info</h1>";
echo "<ul>";
echo "<li><strong>ID:</strong> " . htmlspecialchars($this->getOrderId()) . "</li>";
echo "<li><strong>Date:</strong> " . htmlspecialchars($this->getOrderDate()) . "</li>";
echo "<li><strong>Status:</strong> " . htmlspecialchars($this->getOrderStatus()) . "</li>";
echo "<li><strong>Total:</strong> $" . htmlspecialchars($this->getTotalAmount()) . "</li>";
echo "<li><strong>Payment:</strong> " . htmlspecialchars($this->getPaymentMethod()) . "</li>";
echo "<li><strong>Address:</strong> " . htmlspecialchars($this->getDeliveryAddress()) . "</li>";
echo "</ul>";
echo "</div>";
}
}

// Check if user is logged in
$userId = isset($_SESSION['userid']) ? $_SESSION['userid'] : null;

if ($userId) {
// Link to CSS
echo '<link rel="stylesheet" type="text/css" href="../../css/style.css">'; 

$order = new Ordering($connection, $userId);

// Set order details
$order->setOrderDate(date("Y-m-d H:i:s"));
$order->setOrderStatus('Pending');
$order->setTotalAmount(array_sum(array_map(function($productid, $quantity) use ($connection) {
// calculate total amount
if (!is_numeric($productid) || !is_numeric($quantity) || $quantity <= 0) { return 0; }

$stmt = $connection->prepare("SELECT price FROM products WHERE productid = :id");
$stmt->bindParam(':id', $productid, PDO::PARAM_INT);
$stmt->execute();
$product = $stmt->fetch(PDO::FETCH_ASSOC);
return ($product['price'] ?? 0) * $quantity;
}, array_keys($_SESSION['cart'] ?? []), $_SESSION['cart'] ?? [])));
$order->setPaymentMethod('Credit Card');
$order->setDeliveryAddress('123 Example Address'); // Delivery address

$order->placeOrder();
} else {
// Message if not logged in
echo "<div class='cart-message'>You gotta log in to place orders.</div>";
}
?>

<!-- Back to Home Button -->
<div class="back-home">
<a href="../../index.php" class="back-home-button">Go Back Home</a>
</div>

</body>
</html>
