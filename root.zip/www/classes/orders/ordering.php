<?php
session_start();
require_once '../includes/DBconnect.php';

class Ordering {
    private $connection;
    private $orderId;
    private $orderDate;
    private $orderStatus;
    private $totalAmount;
    private $paymentMethod;
    private $deliveryAddress;
    private $userId;

    public function __construct($pdo, $userId) {
        $this->connection = $pdo;
        $this->userId = $userId;
    }

    // Setters and Getters
    public function setOrderId($orderId) {
        $this->orderId = $orderId;
    }

    public function getOrderId() {
        return $this->orderId;
    }

    public function setOrderDate($orderDate) {
        $this->orderDate = $orderDate;
    }

    public function getOrderDate() { 
        return $this->orderDate;
    }

    public function setOrderStatus($orderStatus) {
        $this->orderStatus = $orderStatus;
    }

    public function getOrderStatus() { 
        return $this->orderStatus;
    }

    public function setTotalAmount($totalAmount) {
        $this->totalAmount = $totalAmount;
    }

    public function getTotalAmount() {
        return $this->totalAmount;
    }

    public function setPaymentMethod($paymentMethod) {
        $this->paymentMethod = $paymentMethod;
    }

    public function getPaymentMethod() {
        return $this->paymentMethod;
    }

    public function setDeliveryAddress($deliveryAddress) {
        $this->deliveryAddress = $deliveryAddress;
    }

    public function getDeliveryAddress() {
        return $this->deliveryAddress;
    }

    public function placeOrder() {
        // Insert order details into the database
        $stmt = $this->connection->prepare("INSERT INTO orders (user_id, order_date, order_status, total_amount, payment_method, delivery_address) VALUES (:user_id, :order_date, :order_status, :total_amount, :payment_method, :delivery_address)");
        $stmt->bindParam(':user_id', $this->userId);
        $stmt->bindParam(':order_date', $this->orderDate);
        $stmt->bindParam(':order_status', $this->orderStatus);
        $stmt->bindParam(':total_amount', $this->totalAmount);
        $stmt->bindParam(':payment_method', $this->paymentMethod);
        $stmt->bindParam(':delivery_address', $this->deliveryAddress);
        $stmt->execute();

        // Get the inserted order ID
        $this->orderId = $this->connection->lastInsertId();

        // Insert each cart item into order_items table
        $stmt = $this->connection->prepare("INSERT INTO order_items (order_id, product_id, quantity) VALUES (:order_id, :product_id, :quantity)");

        foreach ($_SESSION['cart'] as $product_id => $quantity) {
            $stmt->bindParam(':order_id', $this->orderId);
            $stmt->bindParam(':product_id', $product_id);
            $stmt->bindParam(':quantity', $quantity);
            $stmt->execute();
        }

        // Clear the cart after placing the order
        unset($_SESSION['cart']);

        echo "Order placed successfully!<br/>";
        echo "Order ID: " . $this->getOrderId() . "<br/>";
        echo "Order Date: " . $this->getOrderDate() . "<br/>";
        echo "Order Status: " . $this->getOrderStatus() . "<br/>";
        echo "Total Amount: $" . $this->getTotalAmount() . "<br/>";
        echo "Payment Method: " . $this->getPaymentMethod() . "<br/>";
        echo "Delivery Address: " . $this->getDeliveryAddress() . "<br/>";
    }

    public function viewOrderDetails() {
        // Display order details
        echo "<h1>Order Details</h1>";
        echo "Order ID: " . htmlspecialchars($this->getOrderId()) . "<br/>";
        echo "Order Date: " . htmlspecialchars($this->getOrderDate()) . "<br/>";
        echo "Order Status: " . htmlspecialchars($this->getOrderStatus()) . "<br/>";
        echo "Total Amount: $" . htmlspecialchars($this->getTotalAmount()) . "<br/>";
        echo "Payment Method: " . htmlspecialchars($this->getPaymentMethod()) . "<br/>";
        echo "Delivery Address: " . htmlspecialchars($this->getDeliveryAddress()) . "<br/><br/>";
    }
}

// Fetch logged-in user's ID
$userId = isset($_SESSION['userid']) ? $_SESSION['userid'] : null;

if ($userId) {
    $order = new Ordering($pdo, $userId);

    // Set order details
    $order->setOrderDate(date("Y-m-d H:i:s"));
    $order->setOrderStatus('Pending');
    $order->setTotalAmount(array_sum(array_map(function($product_id, $quantity) use ($pdo) {
        $stmt = $pdo->prepare("SELECT price FROM products WHERE id = :id");
        $stmt->bindParam(':id', $product_id, PDO::PARAM_INT);
        $stmt->execute();
        $product = $stmt->fetch(PDO::FETCH_ASSOC);
        return ($product['price'] ?? 0) * $quantity;
    }, array_keys($_SESSION['cart']), $_SESSION['cart'])));
    $order->setPaymentMethod('Credit Card'); // Or fetch from user input
    $order->setDeliveryAddress('123 Example Address'); // Or fetch from user input

    // Place the order
    $order->placeOrder();
} else {
    echo "You need to be logged in to place an order.";
}
?>
