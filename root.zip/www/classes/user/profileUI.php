<?php

class profileU {
    public $profileid;
    public $username;
    public $passwordU;
    public $phonenumber;
    public $dateofbirth;
    public $cardnumber;
    public $profile_picture; 
    public $date; 

    // Setters and Getters for each property
    public function setprofileid($profileid) {
        $this->profileid = $profileid;
    }

    public function getprofileid() {
        return $this->profileid;
    }

    public function setusername($username) {
        $this->username = $username;
    }

    public function getusername() {
        return $this->username;
    }

    public function setpasswordU($passwordU) {
        $this->passwordU = $passwordU;
    }

    public function getpasswordU() {
        return $this->passwordU;
    }

    public function setphonenumber($phonenumber) {
        $this->phonenumber = $phonenumber;
    }

    public function getphonenumber() {
        return $this->phonenumber;
    }

    public function setdateofbirth($dateofbirth) {
        $this->dateofbirth = $dateofbirth;
    }

    public function getdateofbirth() {
        return $this->dateofbirth;
    }

    public function setcardnumber($cardnumber) {
        $this->cardnumber = $cardnumber;
    }

    public function getcardnumber() {
        return $this->cardnumber;
    }

    public function setprofile_picture($profile_picture) { 
        $this->profile_picture = $profile_picture;
    }

    public function getprofile_picture() { 
        return $this->profile_picture;
    }

    public function setDate($date) { 
        $this->date = $date;
    }

    public function getDate() { 
        return $this->date;
    }

    // Method to update and display profile data
    public function updateProfile() {
        echo "Profile ID: " . $this->getprofileid() . "<br/>";
        echo "Username: " . $this->getusername() . "<br/>";
        echo "Date of Birth: " . $this->getdateofbirth() . "<br/>";
        echo "Phone Number: " . $this->getphonenumber() . "<br/>";
        echo "Password: " . $this->getpasswordU() . "<br/>";
        echo "Profile Picture: " . $this->getprofile_picture() . "<br/><br/>";
    }
}

// Creating and setting profile objects
$profileA = new profileU();
$profileB = new profileU();

// Code for profile A
$profileA->setprofileid(1);
$profileA->setusername('userA');
$profileA->setdateofbirth('1995-01-15');
$profileA->setpasswordU('passwordA');
$profileA->setphonenumber('123-456-7890');
$profileA->setprofile_picture('profileA.jpg'); // Setting profile picture for user A

// Code for profile B
$profileB->setprofileid(2);
$profileB->setusername('userB');
$profileB->setdateofbirth('1998-06-20');
$profileB->setpasswordU('passwordB');
$profileB->setphonenumber('098-765-4321');
$profileB->setprofile_picture('profileB.jpg'); // Setting profile picture for user B

// Update and display profile data
$profileA->updateProfile();
$profileB->updateProfile();

?>
