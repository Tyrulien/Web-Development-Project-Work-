<?php
session_start();
require_once '../../includes/DBconnect.php'; // Adjusted path to DBconnect.php
require_once 'users.php'; // Since profile.php and users.php are now in the same directory, no need to adjust the path here

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: loginAction.php");
    exit;
}

$pdo = $connection;
$users = new Users($pdo);

// Fetch user profile data
$userid = $_SESSION['userid'];
$userData = $users->getUserProfile($userid);

if (!$userData) {
    echo "Unable to retrieve profile information.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>User Profile</title>
    <style>
        /* Pastel theme styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f8ff;
            color: #333;
            padding: 20px;
        }

        .profile-container {
            width: 300px;
            margin: 0 auto;
            background-color: #f5fffa;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #98fb98;
            text-align: center;
        }

        .profile-info {
            margin-bottom: 20px;
        }

        .profile-info p {
            margin: 5px 0;
            color: #3cb371;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #3cb371;
            text-decoration: none;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="profile-container">
        <h2>User Profile</h2>
        <div class="profile-info">
            <p><strong>First Name:</strong> <?= htmlspecialchars($userData['firstname']) ?></p>
            <p><strong>Last Name:</strong> <?= htmlspecialchars($userData['lastname']) ?></p>
            <p><strong>Email:</strong> <?= htmlspecialchars($userData['email']) ?></p>
        </div>
        <a class="back-link" href="../../index.php">Back to Home</a>
    </div>
</body>
</html>
