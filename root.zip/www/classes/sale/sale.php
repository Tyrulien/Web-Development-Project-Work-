<?php

class sale {
    public $saleId;
    public $salePrice;
    public $sellerNumber;
    public $productid; // New property for the product ID
    public $date; // New property for the sale date

    // Setters and Getters for each property
    public function setsaleId($saleId) {
        $this->saleId = $saleId;
    }

    public function getsaleId() {
        return $this->saleId;
    }

    public function setsalePrice($salePrice) {
        $this->salePrice = $salePrice;
    }

    public function getsalePrice() {
        return $this->salePrice;
    }

    public function setsellerNumber($sellerNumber) {
        $this->sellerNumber = $sellerNumber;
    }

    public function getsellerNumber() {
        return $this->sellerNumber;
    }

    public function setproductid($productid) { // Setter for product ID
        $this->productid = $productid;
    }

    public function getproductid() { // Getter for product ID
        return $this->productid;
    }

    public function setDate($date) { // Setter for the timestamp
        $this->date = $date;
    }

    public function getDate() { // Getter for the timestamp
        return $this->date;
    }

    // Method to display sale data
    public function displaySale() {
        echo "Sale ID: " . $this->getsaleId() . "<br/>";
        echo "Sale Price: " . $this->getsalePrice() . "<br/>";
        echo "Seller Number: " . $this->getsellerNumber() . "<br/>";
        echo "Product ID: " . $this->getproductid() . "<br/>";
        echo "Date: " . $this->getDate() . "<br/><br/>";
    }
}

// Creating and setting sale objects
$SaleA = new sale();
$SaleB = new sale();

// Code for Sale A
$SaleA->setsaleId(1);
$SaleA->setsalePrice(100);
$SaleA->setsellerNumber(101);
$SaleA->setproductid(202);
$SaleA->setDate(date("Y-m-d H:i:s")); // Setting the current date and time

// Code for Sale B
$SaleB->setsaleId(2);
$SaleB->setsalePrice(150);
$SaleB->setsellerNumber(102);
$SaleB->setproductid(203);
$SaleB->setDate(date("Y-m-d H:i:s")); // Setting the current date and time

// Display sale data
$SaleA->displaySale();
$SaleB->displaySale();

?>
